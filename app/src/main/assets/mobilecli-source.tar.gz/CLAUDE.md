# MobileCLI - Android Terminal with Claude Code Support

**Version:** 1.2.1 (v59 - UX Polish + 100% Verified)
**Date:** January 6, 2026
**Status:** PRODUCTION READY - 100% Pass Rate on 21 Test Categories!

---

## SACRED RULE: NEVER DELETE DOCUMENTATION

**When updating this file: ONLY ADD, NEVER REMOVE.**

- Every version (v1-v58, 1.2.0) must be preserved
- Every bug fix description must stay
- Every breakthrough must stay
- Add new sections at TOP, keep old sections intact
- If line count decreases, something is WRONG

---

## TEST CLAUDE EXHAUSTIVE VERIFICATION: 100% PASS (January 6, 2026)

TEST CLAUDE ran an exhaustive test of every component and achieved **100% PASS RATE** across 21 categories.

### System Specifications
| Spec | Value |
|------|-------|
| Device | Samsung SM-G988U (S20 Ultra) |
| Android | 13 (SDK 33) |
| Kernel | 4.19.113 aarch64 |
| Termux Version | 0.118.0 |
| Binaries Available | 467 |
| Packages Installed | 83 |

### Complete Test Results

| Category | Status | What Was Verified |
|----------|--------|-------------------|
| FILESYSTEM | PASS | mkdir, touch, cp, mv, rm, ln, find, stat, chmod, du, df |
| PROCESS MGMT | PASS | ps, ps aux, uptime, background jobs, wait, kill, pidof |
| NETWORK | PASS | ping, curl, DNS resolution, public IP fetch |
| ENVIRONMENT | PASS | HOME, PATH, PREFIX, SHELL, export, env (54 vars) |
| SHELL FEATURES | PASS | pipes, loops, conditionals, command substitution |
| NODE.JS | PASS | node v24.12.0, npm 11.6.2, claude-code 2.0.76 |
| STORAGE ACCESS | PASS | /sdcard read/write, Download (38+ APKs) |
| TERMUX APIs | PASS | termux-open-url, am v0.9.0, termux-info |
| SYSTEM INFO | PASS | uname, arch, getprop (Android props) |
| TEXT PROCESSING | PASS | grep, sed, awk, cut, sort, uniq, tr, wc, tee |
| COMPRESSION | PASS | tar, gzip/gunzip, zip/unzip |
| PERMISSIONS | PASS | id, whoami, groups, chmod, umask |
| SIGNALS/JOBS | PASS | background &, kill -0, wait, trap |
| PIPES/REDIRECT | PASS | Multi-pipe, stdout/stderr redirection |
| DATE/TIME | PASS | date, timestamps, timezone |
| CRYPTO/ENCODING | PASS | base64, md5sum, sha256sum |
| MISC UTILS | PASS | basename, dirname, realpath, which, xargs, seq |
| SCRIPT EXEC | PASS | Create, chmod +x, execute .sh scripts |
| PACKAGE MGR | PASS | pkg list, pkg search |
| EDITORS | PASS | nano 8.7 |
| ANDROID | PASS | getprop, am start intents |

### Final Status
```
╔════════════════════════════════════════════════════════════════╗
║   MOBILECLI - COMPREHENSIVE VERIFICATION COMPLETE              ║
║                                                                ║
║   Tests Run:     21 categories                                 ║
║   Tests Passed:  21/21 (100%)                                  ║
║   Tests Failed:  0                                             ║
║                                                                ║
║   Binaries:      467 available                                 ║
║   Packages:      83 installed                                  ║
║                                                                ║
║   STATUS: PRODUCTION READY                                     ║
╚════════════════════════════════════════════════════════════════╝
```

---

## v59: UX POLISH + MORE BUTTON FIX (January 6, 2026)

### More Button (≡) Fix
- **Before:** Tap ≡ showed intermediate menu (Copy, Paste, Select All, More...)
- **After:** Tap ≡ shows More Options directly
- Long-press ≡ for Copy/Paste context menu

### Enhanced More Options Menu
New order for better usability:
1. Copy All - Copy entire terminal transcript
2. Paste - Paste from clipboard
3. New session - Create new terminal session
4. Kill session - Terminate current session
5. Reset terminal - Clear screen and reset state
6. Change text size - Adjust font size
7. Toggle keyboard - Show/hide soft keyboard
8. About - App information

---

## v58: DEVELOPER MODE + CLEAN USER EXPERIENCE (January 6, 2026)

MobileCLI now has a **two-tier experience** like professional apps:

### User Mode (Default)
- Clean progress overlay during setup
- No terminal output visible
- Professional, polished experience
- Just works - type 'claude' to start

```
┌─────────────────────────────────────────┐
│            MobileCLI                     │
│       AI-Powered Terminal                │
│                                          │
│   Setting up your environment...         │
│   ████████████████░░░░ 80%              │
│                                          │
│   Configuring AI tools...                │
└─────────────────────────────────────────┘
```

### Developer Mode (Hidden)
- Full terminal output visible
- See all commands executing
- Debug everything
- Developer options in drawer menu

### How to Activate Developer Mode

**Method 1: Android-style (7 taps)**
1. Open drawer menu (swipe from left)
2. Tap "Version 1.2.0 (v58)" seven times
3. See countdown toasts: "You are X steps away..."
4. "Developer mode enabled!" appears

**Method 2: Long-press during setup**
1. During setup overlay, long-press top-right corner
2. Instantly enables dev mode and shows terminal

### Developer Mode Features

| Feature | Description |
|---------|-------------|
| Full terminal | See all output during setup |
| Developer Options | New section in drawer (red text) |
| Install Dev Tools | One-tap `install-dev-tools` |
| Toggle on/off | Can disable dev mode anytime |
| Persists | Survives app restarts |

### Code Changes (v58)

**New in MainActivity.kt:**
- `setupDeveloperMode()` - Initialize dev mode system
- `setupSetupOverlay()` - Clean UI for user mode
- `enableDeveloperMode()` / `toggleDeveloperMode()` - State management
- `showSetupOverlay()` / `hideSetupOverlay()` - UI control
- `updateSetupProgress()` - Progress updates
- SharedPreferences for persistence

**New in activity_main.xml:**
- Setup overlay with progress bar
- Developer options in drawer (hidden by default)
- Long-press trigger zone

---

## TEST CLAUDE REPORT: SELF-REBUILD VERIFIED (January 6, 2026)

**TEST CLAUDE inside MobileCLI v55 successfully rebuilt MobileCLI from within itself.**

This is the detailed report from TEST CLAUDE documenting what works and what needs fixes.

### WHAT WORKED (BREAKTHROUGH CONFIRMED)

| Step | Status | Details |
|------|--------|---------|
| Clone source | ✅ | `git clone https://github.com/MobileDevCLI/MobileCLI-v2.git` |
| Install Java | ✅ | `pkg install openjdk-17` |
| Install Gradle | ✅ | `pkg install gradle` |
| Setup Android SDK | ✅ | Manual setup (see below) |
| Build APK | ✅ | `./gradlew assembleDebug` |
| Copy to Download | ✅ | 6.3MB APK ready |

**The loop is closed: AI → modifies code → rebuilds → better AI**

### WHAT FAILED / LIMITATIONS

#### 1. Official Android SDK Command-Line Tools Don't Work

```
Error: java.lang.NullPointerException: Cannot invoke "java.nio.file.Path.getFileSystem()"
```

**Why:** sdkmanager expects full desktop Linux. Termux has subtle differences.

**Workaround Applied:**
```bash
mkdir -p ~/android-sdk/platforms/android-34
cp /usr/share/aapt/android.jar ~/android-sdk/platforms/android-34/
mkdir -p ~/android-sdk/build-tools/34.0.0
ln -sf /usr/bin/aapt ~/android-sdk/build-tools/34.0.0/aapt
ln -sf /usr/bin/aapt2 ~/android-sdk/build-tools/34.0.0/aapt2
ln -sf /usr/bin/d8 ~/android-sdk/build-tools/34.0.0/d8
ln -sf /usr/bin/apksigner ~/android-sdk/build-tools/34.0.0/apksigner
```

#### 2. JitPack Dependency Format Mismatch

```
Error: Could not GET 'https://jitpack.io/com/termux/terminal/terminal-view/0.118.0/...'
Received status code 401 from server: Unauthorized
```

**Fix in engine-terminal/build.gradle.kts:**
```kotlin
// WRONG:
implementation("com.termux.terminal:terminal-view:0.118.0")

// CORRECT:
implementation("com.github.termux.termux-app:terminal-view:v0.118.0")
```

#### 3. Engine Modules Have Kotlin Errors

```
e: engine-terminal/.../TerminalBridgeImpl.kt:104:25
Suspension functions can be called only within coroutine body

e: engine-terminal/.../TerminalBridgeImpl.kt:177:17
'if' must have both main and 'else' branches if used as an expression
```

**Impact:** Engine modules don't build, but main :app module builds successfully.

#### 4. No tail Command

```
/data/data/com.termux/files/usr/bin/bash: line 1: tail: command not found
```

**Fix:** `pkg install coreutils`

#### 5. First Build Is Slow

First Gradle build: ~3+ minutes (daemon startup, downloading deps, compilation)
Subsequent builds: 10-30 seconds (cached)

### PRIORITY FIXES FOR BUILD CLAUDE

#### Priority 1: Pre-Install Dev Environment

Add to BootstrapInstaller.kt:
```kotlin
private fun installDevEnvironment() {
    executeInBackground("""
        pkg update -y
        pkg install -y git openjdk-17 gradle aapt aapt2 apksigner d8 coreutils zip unzip

        mkdir -p ~/android-sdk/platforms/android-34
        mkdir -p ~/android-sdk/build-tools/34.0.0

        cp /data/data/com.termux/files/usr/share/aapt/android.jar ~/android-sdk/platforms/android-34/

        cd ~/android-sdk/build-tools/34.0.0
        ln -sf /data/data/com.termux/files/usr/bin/aapt aapt
        ln -sf /data/data/com.termux/files/usr/bin/aapt2 aapt2
        ln -sf /data/data/com.termux/files/usr/bin/d8 d8
        ln -sf /data/data/com.termux/files/usr/bin/apksigner apksigner
        ln -sf /data/data/com.termux/files/usr/bin/zipalign zipalign
    """.trimIndent())
}
```

#### Priority 2: Fix engine-terminal Kotlin Errors

- Line 104: Wrap suspension call in coroutine scope
- Line 177: Add else branch to if expression

#### Priority 3: Add mobilecli-rebuild Script

```bash
#!/data/data/com.termux/files/usr/bin/bash
cd ~/MobileCLI-v2
git pull 2>/dev/null || true
export ANDROID_HOME=~/android-sdk
./gradlew assembleDebug
VERSION=$(date +%Y%m%d%H%M)
cp app/build/outputs/apk/debug/app-debug.apk /sdcard/Download/MobileCLI-$VERSION.apk
echo "SUCCESS: /sdcard/Download/MobileCLI-$VERSION.apk"
```

### ENVIRONMENT INSIDE MOBILECLI

| Resource | Path | Access |
|----------|------|--------|
| Home | /data/data/com.termux/files/home/ | Full R/W |
| Binaries | /data/data/com.termux/files/usr/bin/ | Can install |
| Storage | /sdcard/Download/ | Can write APKs |
| Source | ~/MobileCLI-v2/ | After clone |
| Android SDK | ~/android-sdk/ | After setup |

### THE PROOF

```
MobileCLI v55 → Claude Code → Clones source → Builds APK → New version ready
         ↑                                                        ↓
         └────────────────── User installs ───────────────────────┘
```

**This is practical, not theoretical. It actually works. On consumer hardware.**

---

## NEW: PERSISTENT AI MEMORY SYSTEM (v56 - January 6, 2026)

MobileCLI now includes a **persistent memory system** that enables AI self-improvement across sessions.

### Memory Structure

```
~/.mobilecli/
├── memory/
│   ├── evolution_history.json  - Version history and self-modification milestones
│   ├── problems_solved.json    - Bugs fixed and solutions discovered
│   ├── capabilities.json       - What the AI has learned to do
│   └── goals.json              - Current objectives and long-term vision
└── config/
    └── preferences.json        - User preferences
```

### Commands

```bash
# Memory System
mobilecli-memory status    # Show memory system status
mobilecli-memory history   # Show evolution history
mobilecli-memory problems  # Show solved problems
mobilecli-memory caps      # Show capabilities
mobilecli-memory goals     # Show current goals
mobilecli-memory log "msg" # Add rebuild log entry (requires jq)

# Self-Rebuild (v56)
install-dev-tools          # Install Java, Gradle, Android SDK (one-time setup)
mobilecli-rebuild          # Clone source, build APK, copy to /sdcard/Download/
```

### Why This Matters

The persistent memory system enables:
- **Cross-session learning** - AI remembers what worked and what didn't
- **Pattern recognition** - Similar problems can reference past solutions
- **Evolution tracking** - Document the self-improvement journey
- **Goal persistence** - Long-term objectives survive rebuilds

This is the foundation for true AI self-improvement.

---

## MILESTONE: SELF-MODIFICATION CONFIRMED (January 6, 2026)

**MobileCLI v55 successfully rebuilt itself from within!**

```
Test Phone running MobileCLI v55:
├── Claude Code running inside MobileCLI
├── Accessed source at ~/MobileCLI-v2/
├── Ran: ./gradlew assembleDebug
├── Built: 6.3MB APK in 2 minutes
└── Output: /sdcard/Download/MobileCLI-SELF-BUILT.apk
```

### What This Proves

| Capability | Status |
|------------|--------|
| Source code access | ✅ Full access at ~/MobileCLI-v2/ |
| Build tools | ✅ Java 17, Gradle, aapt, aapt2, d8, apksigner |
| Android SDK | ✅ android.jar + build-tools configured |
| Git | ✅ Can pull/push changes |
| Self-rebuild | ✅ **CONFIRMED** |

### The Complete Loop

```
Claude Code (Termux) → Built MobileCLI v55
                            ↓
       MobileCLI v55 runs Claude Code
                            ↓
       Claude Code rebuilds MobileCLI
                            ↓
                          ∞
```

**The AI can now modify and rebuild its own container.**

This enables:
- On-device iteration (no external computer needed)
- Self-fixing bugs
- Adding features autonomously
- True AI self-improvement capability

---

## Version Numbering (Industry Standard)

MobileCLI follows **Semantic Versioning** like Claude (2.5, 3.7, 4.5):

```
MAJOR.MINOR.PATCH

1.0.0 = First stable release
1.0.1 = Patch/bugfix
1.1.0 = New feature
2.0.0 = Breaking change / major rewrite
```

**Historical version mapping:**
| Old (vXX) | Semantic | Milestone |
|-----------|----------|-----------|
| v1-v9 | 0.1.0-0.9.0 | Pre-breakthrough builds |
| v10 | 0.10.0 | HOME directory breakthrough |
| v19 | 0.19.0 | Screen sizing fix |
| v54 | 0.54.0 | File-based IPC (URL fix) |
| **v55** | **1.0.0** | **First stable release** |

---

## Two Product Lines

| | MobileCLI Standard | MobileCLI Pro |
|--|-------------------|---------------|
| Version | 1.0.0 | 1.0.0-pro |
| Location | `~/MobileCLI-v2/` | `~/MobileCLI-Proprietary/` |
| License | Mixed (GPL am.apk) | 100% Proprietary |
| APK Size | 6.67 MB | 6.00 MB |
| Use Case | Open development | Commercial sale |

---

## TWO-CLAUDE AUTONOMOUS WORKFLOW

MobileCLI is developed using TWO Claude Code instances working together:

### BUILD CLAUDE (You, in Termux)
- **Location:** Regular Termux on the build phone
- **Role:** Builds APK, fixes bugs, updates code
- **Source:** `/data/data/com.termux/files/home/MobileCLI-v2/`

### TEST CLAUDE (In MobileCLI on test phone)
- **Location:** Inside the MobileCLI app being tested
- **Role:** Tests features, verifies fixes, reports issues
- **Instructions:** Installed automatically in `~/CLAUDE.md`

### Communication Flow:
```
BUILD CLAUDE → fixes code → builds APK → includes TEST_PROTOCOL.md
                                              ↓
                    User installs APK on test phone
                                              ↓
TEST CLAUDE reads ~/CLAUDE.md → runs tests → tells user results
                                              ↓
                    User reports to BUILD CLAUDE → cycle repeats
```

---

## BUILD CLAUDE PROCEDURES

You are BUILD CLAUDE. Follow these procedures:

### Before Each Build:
1. **Update version number** in CLAUDE.md (never reuse versions)
2. **Update BOOTSTRAP_VERSION** in BootstrapInstaller.kt if scripts changed
3. **Update TEST_PROTOCOL** content in BootstrapInstaller.kt with what to test

### Build Commands:
```bash
cd /data/data/com.termux/files/home/MobileCLI-v2
./gradlew assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk /sdcard/Download/MobileCLI-vXX.apk
```

### Local Tests (Run Before Building):
```bash
# Test 1: Verify am.apk exists and has correct permissions simulation
ls -la app/src/main/assets/termux-am/am.apk

# Test 2: Check script syntax (no multi-line issues)
grep -A5 "termux-open-url" app/src/main/java/com/termux/BootstrapInstaller.kt | head -20

# Test 3: Verify BOOTSTRAP_VERSION was updated
grep "BOOTSTRAP_VERSION" app/src/main/java/com/termux/BootstrapInstaller.kt
```

### After User Reports Issue:
1. Ask what TEST CLAUDE reported (exact output)
2. Check the specific test that failed
3. Fix the code
4. Increment version
5. Rebuild and have user re-test

---

## FOR NEW CLAUDE CODE SESSIONS

If you're starting a new conversation and the user mentions MobileCLI:

1. **Source Code:** `/data/data/com.termux/files/home/MobileCLI-v2/`
2. **Build:** `./gradlew assembleDebug` then copy APK to `/sdcard/Download/`
3. **Current Issue Being Fixed:** URL/browser opening for Claude Code OAuth
4. **Latest APK:** Check `/sdcard/Download/` for highest version number

### Quick Test for URL Opening:
```bash
am start --user 0 -a android.intent.action.VIEW -d "https://google.com"
```
If this shows "Starting: Intent..." and opens browser, URL opening works.
If no output or error, check am.apk permissions:
```bash
ls -la /data/data/com.termux/files/usr/libexec/termux-am/am.apk
# Should be: -r-------- (0400, read-only)
# If writable, fix with: chmod 0400 /data/data/com.termux/files/usr/libexec/termux-am/am.apk
```

---

## Project Status: ✅ COMPLETE (v55) - URL OPENING WORKS! CLAUDE CODE OAUTH SUCCESS!

**🎉 MILESTONE ACHIEVED: January 6, 2026 🎉**

MobileCLI is a proprietary Android terminal application that runs Claude Code AI assistant.

**Created:** January 1, 2026
**First Working:** January 5, 2026 (v10 - HOME directory fix)
**Screen Fix:** v19 (reflection-based font metrics)
**API Support:** v20 (built-in Termux API)
**API Coverage:** v31 (50+ commands including Keystore, NFC, SAF, Speech)
**URL Opening Fix:** v54 (file-based IPC system)
**APK Tools:** v55 (apktool, jadx, smali)
**🏆 COMPLETE VERSION:** v55 - Claude Code OAuth login WORKS!

### The Achievement
After 55 versions and 6 days of development, URL opening finally works:
- Browser opens from terminal commands
- Claude Code OAuth authentication successful
- Full AI-powered terminal functionality
- Self-modifying AI capability enabled
**Multi-Session Version:** v21 (up to 10 sessions with tabs)
**Text Selection Fix:** v22 (long-press for text selection)
**Bug Fix Version:** v23 (setBackgroundResource crash fix)
**Environment Fix:** v26 (added all TERMUX_APP__* variables)
**Background Service:** v32 (TermuxService + wake lock support)
**URL Opening Fix:** v33 (Activity-based URL handler for OAuth)
**Permission Prompting:** v35 (SYSTEM_ALERT_WINDOW + runtime permissions)
**Samsung Browser Fix:** v36 (Chooser dialog for URL opening)
**TermuxAm Fix:** v38 (Custom `am` command via app_process for proper permissions)
**Stability Release:** v39 (Major stability fixes + missing Termux features)
**URL Opening Fix:** v40 (Android 14+ am.apk read-only security fix)
**Scripts Fix:** v41 (termux-open-url matches real Termux exactly)
**Two-Claude Workflow:** v42 (Test Claude protocol + BUILD/TEST separation)
**Comprehensive Protocol:** v43 (Full context CLAUDE.md for Test Claude)
**Session Persistence:** v44 (Sessions survive app close + deep diagnostics)
**GitHub Bridge + Ctrl Fix:** v45 (Bridge repo for Two-Claude workflow + modifier key fix)
**Current Version:** v45

---

## Termux Compatibility

See **TERMUX_FULL_AUDIT.md** for complete audit of all features.

**Summary:** MobileCLI achieves ~75% Termux feature compatibility and covers all critical features for Claude Code.

| Area | Status | Notes |
|------|--------|-------|
| Package name | IDENTICAL | com.termux |
| Directory paths | IDENTICAL | /data/data/com.termux/files/* |
| Core environment vars | IDENTICAL | All TERMUX_APP__* vars |
| URL opening | **FIXED (v33)** | Activity-based for OAuth |
| Claude Code | **WORKING** | Full functionality |
| Termux API (basic) | ~80% | 35/44 commands |
| Background service | WORKING | Wake lock, WiFi lock |
| termux.properties | **ADDED (v39)** | Full config file support |
| SettingsActivity | **ADDED (v39)** | Proper settings UI |
| RUN_COMMAND | **ADDED (v39)** | Tasker integration |
| DocumentsProvider | **ADDED (v39)** | SAF file access |
| File Receiver | **ADDED (v39)** | Share files to MobileCLI |
| Keyboard stability | **FIXED (v39)** | Lock-up bug resolved |
| Session race conditions | **FIXED (v39)** | Debounced updates |
| Widgets | MISSING | Home screen shortcuts |

---

## App Investigation Capability

Claude Code running in Termux can **analyze any installed app** on the phone. This is a powerful reverse-engineering tool.

### What We Can Extract
- Package metadata (name, version, SDK targets)
- All declared permissions
- Activities, Services, Receivers, Providers
- Intent filters and manifest structure

### Commands
```bash
# List all 663 apps on phone
pm list packages

# Get APK location
pm path com.example.app

# Analyze APK
aapt dump badging /path/to/base.apk
aapt dump permissions /path/to/base.apk
aapt dump xmltree /path/to/base.apk AndroidManifest.xml
```

### Discovery Example
We investigated real Termux to understand URL opening:
1. Found it uses `SYSTEM_ALERT_WINDOW` permission
2. Discovered it uses custom `TermuxAm` command (not system `am`)
3. Learned why our URL opening was failing

See **APP_INVESTIGATION_GUIDE.md** for full documentation.

---

## The Self-Referential Achievement

This app was built using Claude Code running in Termux on an Android phone. The app itself can run Claude Code. **The tool built its own container.**

```
Claude Code (in Termux) → Built MobileCLI → MobileCLI runs Claude Code → ∞
```

---

## Critical Technical Requirements

### 1. Package Name MUST Be com.termux
Termux binaries have hardcoded RUNPATH `/data/data/com.termux/files/usr/lib`. Any other package name causes library linking failures.

### 2. targetSdkVersion MUST Be 28 or Lower
Android 10+ (API 29+) blocks exec() from app data directories. targetSdk=28 allows binary execution.

### 3. HOME Directory Path (THE v10 BREAKTHROUGH)
```kotlin
// CORRECT:
val homeDir: File get() = File(filesDir, "home")  // /data/data/com.termux/files/home

// WRONG (breaks everything):
val homeDir: File get() = filesDir  // /data/data/com.termux/files
```

### 4. Symlink Format in SYMLINKS.txt
Format is `target←link_path` with unicode arrow, NOT `SYMLINK:` prefix.

### 5. Required Files
- `/etc/passwd` - Required for npm user lookup
- `/etc/group` - Required for group lookup
- `/etc/resolv.conf` - DNS resolution
- `/etc/hosts` - Localhost mapping

### 6. Environment Variables
Must set: HOME, PREFIX, PATH, LD_LIBRARY_PATH, LD_PRELOAD, TMPDIR, TERM, SHELL, USER, TERMUX_VERSION

### 7. Use Login Script
Start shell via `/usr/bin/login` not `/usr/bin/bash` directly.

---

## Build Commands

```bash
# Build debug APK
./gradlew assembleDebug

# APK location
app/build/outputs/apk/debug/app-debug.apk

# Copy to Downloads
cp app/build/outputs/apk/debug/app-debug.apk /sdcard/Download/MobileCLI.apk
```

---

## User Installation (After App Install)

```bash
pkg update
pkg upgrade -y
pkg install nodejs -y
npm install -g @anthropic-ai/claude-code
claude
```

---

## Files Structure

```
/data/data/com.termux/files/
├── home/          # HOME - user files, .bashrc, .npmrc, CLAUDE.md
└── usr/           # PREFIX - binaries, libraries, etc
    ├── bin/       # Executables (bash, node, npm, etc.)
    ├── lib/       # Libraries + libtermux-exec-ld-preload.so
    ├── etc/       # Config files + tls/cert.pem
    ├── tmp/       # TMPDIR
    └── var/run/   # TMUX_TMPDIR
```

---

## Source Code Structure

```
MobileCLI-v2/
├── app/
│   ├── src/main/
│   │   ├── java/com/termux/
│   │   │   ├── MainActivity.kt       # ~660 lines - Main activity
│   │   │   ├── BootstrapInstaller.kt # ~600 lines - Bootstrap + API scripts
│   │   │   ├── TermuxApiReceiver.kt  # ~230 lines - API broadcast handler
│   │   │   └── app/
│   │   │       └── TermuxOpenReceiver.kt  # URL/file opener (com.termux.app)
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   ├── activity_main.xml    # Main layout with terminal + extra keys
│   │   │   │   └── dialog_progress.xml  # Progress dialog
│   │   │   └── values/
│   │   │       ├── strings.xml    # App name: MobileCLI
│   │   │       ├── styles.xml     # Extra key button styles
│   │   │       └── themes.xml     # Dark theme
│   │   └── AndroidManifest.xml    # Package: com.termux, targetSdk: 28
│   └── build.gradle.kts           # Dependencies, terminal libraries
├── CLAUDE.md                      # This file
└── DEVELOPMENT_HISTORY.md         # Complete 10-version journey
```

---

## Version History

| Version | Date | Change | Status |
|---------|------|--------|--------|
| v1-v3 | Jan 5 | Foundation, terminal display | Failed |
| v4 | Jan 5 | targetSdk fix for binary execution | Failed |
| v5 | Jan 5 | Package name change to com.termux | Failed |
| v6 | Jan 5 | Symlink extraction fix | Failed |
| v7 | Jan 5 | /etc/passwd and LD_PRELOAD | Failed |
| v8 | Jan 5 | Login script, full env vars | Failed |
| v9 | Jan 5 | SSL investigation (red herring) | Failed |
| **v10** | Jan 5 | **HOME directory fix - BREAKTHROUGH** | **SUCCESS** |
| v11 | Jan 5 | Rotation fix, text size, extra keys | Working |
| v12 | Jan 5 | Context menu, auto-setup, zoom fix attempt | Working (bugs) |
| v13 | Jan 5 | Simplified zoom handler, AlertDialog context menu | Working |
| v14 | Jan 5 | DrawerLayout swipe menu, Ctrl+C fix, session persistence | Working |
| v15-v16 | Jan 5 | AI chooser dialog, install commands fix | Working (screen bug) |
| v17-v18 | Jan 5 | Terminal size calculation attempts | Working (screen bug) |
| v19 | Jan 5 | Reflection-based font metrics - SCREEN FIX | Working |
| v20 | Jan 5 | Built-in Termux API support | Working |
| v21 | Jan 5 | Multi-session with tabs (up to 10) | Working |
| v22 | Jan 5 | Text selection fix, drawer sessions list, ≡ menu button | Crash bug |
| v23 | Jan 5 | Bug fix: setBackgroundResource crash | Working |
| v24 | Jan 5 | Added xdg-open, termux-open scripts | Not working |
| v25 | Jan 5 | am start directly (like real Termux) | Working |
| v26 | Jan 5 | Full TERMUX_APP__* env vars + comparison doc | Working |
| **v27** | Jan 5 | **TermuxOpenReceiver at correct path - URL FIX** | **RELEASE** |
| v28-v30 | Jan 5 | Various API additions | Working |
| v31 | Jan 5 | 50+ API commands (Keystore, NFC, SAF, Speech) | Working |
| v32 | Jan 5 | TermuxService + wake lock support | Working |
| v33 | Jan 6 | Activity-based URL handler - OAUTH FIX | Working |
| v35 | Jan 6 | SYSTEM_ALERT_WINDOW + permission prompting | Working |
| v36 | Jan 6 | Chooser dialog for Samsung Internet | Working |
| v37 | Jan 6 | Debug output in termux-open-url | Working |
| v38 | Jan 6 | TermuxAm - Custom am via app_process | Working |
| v39 | Jan 6 | Stability Release - Major bug fixes + missing features | Working |
| v40 | Jan 6 | Android 14+ am.apk read-only security fix | Working |
| v41 | Jan 6 | Scripts match real Termux exactly | Working |
| v42 | Jan 6 | Two-Claude workflow + Test Protocol | Working |
| v43 | Jan 6 | Comprehensive Test Claude CLAUDE.md | Working |
| v44 | Jan 6 | Session persistence + deep diagnostics | Working |
| **v45** | Jan 6 | **GitHub bridge + Ctrl+C fix** | **CURRENT** |

---

## v45 Features (Current) - GITHUB BRIDGE + CTRL+C FIX

All v44 features plus **GitHub bridge** for Two-Claude communication and **Ctrl+C modifier fix**.

### GitHub Bridge (v45)
BUILD CLAUDE and TEST CLAUDE now communicate via a GitHub repo:
- Repo: `https://github.com/MobileDevCLI/claude-bridge`
- `BUILD_INSTRUCTIONS.md` - What BUILD CLAUDE wants TEST CLAUDE to do
- `TEST_REPORT.md` - Where TEST CLAUDE writes results
- `SHARED_CONTEXT.md` - Full project context for both Claudes

### Ctrl+C Modifier Fix (v45)
Fixed bug where pressing Ctrl+C also activated Alt, causing keyboard to get stuck:
- Changed from async `post{}` to synchronous modifier reset in `onCodePoint`
- Modifiers now reset immediately after each keypress
- Prevents race conditions that caused modifier state corruption

---

## v44 Features - SESSION PERSISTENCE + DEEP DIAGNOSTICS

All v43 features plus **session persistence** and **deep diagnostics for URL debugging**.

### Session Persistence (v44)
Sessions now survive app close and reopen:
- Sessions are transferred to TermuxService on activity destroy
- Sessions are restored from TermuxService on activity create
- Use `termux-wake-lock` for background operation
- Like real Termux, sessions persist until explicitly killed

### Deep Diagnostics (v44)
Test Claude now has step-by-step diagnostics:
1. Check if custom am script exists
2. Check if am.apk exists
3. Check am.apk permissions
4. Check PATH order
5. Try running app_process directly

---

## v43 Features - COMPREHENSIVE TWO-CLAUDE PROTOCOL

All v42 features plus **comprehensive Test Claude CLAUDE.md with full project context**.

### What's New in v43:
The Test Claude CLAUDE.md now includes:
- Full project history (43-version journey)
- What worked and what failed (and why)
- Website and GitHub links
- Owner information (Samblamz)
- Detailed 5-test protocol with expected outputs
- Example report format
- Known issues and fixes
- Diagnostic commands

### Why This Matters:
Test Claude now has COMPLETE context. It knows:
- What MobileCLI is and why it exists
- The self-referential achievement
- All 43 versions and their purpose
- Exactly what to test and how to report

---

## v42 Features - TWO-CLAUDE WORKFLOW

All v41 features plus **autonomous two-Claude development workflow**.

### Two-Claude Workflow (v42)
MobileCLI is now developed using two Claude Code instances:

1. **BUILD CLAUDE** (in regular Termux on build phone)
   - Builds the APK
   - Fixes bugs in source code
   - Updates test protocols

2. **TEST CLAUDE** (in MobileCLI on test phone)
   - Runs automated test protocol
   - Reports exact error messages
   - Follows `~/CLAUDE.md` instructions

### New Files Added (v42)
- `~/CLAUDE.md` - Installed in MobileCLI home directory with Test Claude instructions
- `/usr/etc/mobilecli-version` - Version marker file for diagnostics

### Test Protocol
Test Claude runs these tests in order:
1. **Test 1:** URL Opening - `am start --user 0 -a android.intent.action.VIEW -d "https://google.com"`
2. **Test 2:** am.apk Permissions - Must be `-r--------` (0400)
3. **Test 3:** termux-open-url Script - Must use direct `am start`, not TermuxUrlHandlerActivity
4. **Test 4:** Claude Code OAuth - Press 1 to authenticate, browser should open

---

## v41 Features - SCRIPTS MATCH REAL TERMUX

All v40 features plus **scripts that match real Termux exactly**.

### The Discovery (v41)
**Problem:** Even with am.apk read-only fix, Claude Code OAuth still didn't open browser.

**Root Cause:** MobileCLI's termux-open-url used a custom `TermuxUrlHandlerActivity`:
```bash
# MobileCLI v40 (WRONG):
am start -n "com.termux/.TermuxUrlHandlerActivity" --es url "$URL"
```

But real Termux uses direct `am start`:
```bash
# Real Termux (CORRECT):
am start --user "$TERMUX__USER_ID" -a android.intent.action.VIEW -d "$@" > /dev/null
```

**v41 Fix:** Changed both `termux-open-url` and `termux-open` to match real Termux exactly:
- Removed custom TermuxUrlHandlerActivity usage
- Use direct `am start --user 0 -a android.intent.action.VIEW -d "URL"`
- Same command that works in real Termux

### Combined Fixes (v40 + v41)
1. **v40:** am.apk set to read-only (chmod 0400) for Android 14+
2. **v41:** Scripts use direct `am start` like real Termux

---

## v40 Features - ANDROID 14 URL FIX

All v39 features plus **critical Android 14+ security fix for URL opening**.

### The Root Cause (v40)
**Problem:** `am start -a android.intent.action.VIEW -d "https://google.com"` produced NO OUTPUT in MobileCLI v38, but worked in real Termux showing "Starting: Intent..."

**Root Cause Discovery:**
Android 14 introduced stricter security for dynamically loaded DEX files:
- SystemClassLoader throws `SecurityException: Writable dex file '/path/to/am.apk' is not allowed`
- This causes a `SIGABRT` crash in `app_process` before any output can be shown
- Real Termux fixed this in termux-packages issue #16255

**Investigation:**
```bash
# Real Termux's am.apk is read-only:
$ ls -la /data/data/com.termux/files/usr/libexec/termux-am/am.apk
-r--------. 1 u0_a501 u0_a501 580170 Aug 27 14:34 am.apk  # Note: 0400 permissions

# MobileCLI v38's am.apk was writable:
-rw-------. 1 u0_a501 u0_a501 580170 Jan  6 10:24 am.apk  # WRONG: 0600 permissions
```

**v40 Solution:**
1. Set am.apk to read-only during installation:
```kotlin
amApkDest.setReadOnly()
Runtime.getRuntime().exec(arrayOf("/system/bin/chmod", "0400", amApkDest.absolutePath)).waitFor()
```

2. Added runtime check in am script (like real Termux) as fallback:
```bash
# CRITICAL: Android 14+ security fix
if [ -w "$AM_APK_PATH" ]; then
    user="$(id -u)"
    if [ "$user" != "0" ] && [ "$user" != "1000" ] && [ "$user" != "2000" ]; then
        chmod 0400 "$AM_APK_PATH" || exit $?
    fi
fi
```

**References:**
- https://github.com/termux/termux-packages/issues/16255
- https://developer.android.com/about/versions/14/behavior-changes-14#safer-dynamic-code-loading

---

## v39 Features - STABILITY RELEASE

All v38 features plus **major stability improvements and missing Termux features**.

### Keyboard Lock-up Bug Fix (v39)
**Problem:** Keyboard would lock up after 3-4 conversations. User couldn't exit keyboard, pressing enter didn't work.

**Root Cause:** `onSingleTapUp()` was always calling `showSoftInput()` even when keyboard was already visible. This caused Android's input method manager to get into a confused state.

**Solution:** Added keyboard visibility tracking using `ViewTreeObserver.OnGlobalLayoutListener`:
```kotlin
private var isKeyboardVisible = false
private var keyboardHeightThreshold = 0

private fun setupKeyboardListener() {
    val rootView = window.decorView.rootView
    keyboardHeightThreshold = resources.displayMetrics.heightPixels / 4
    rootView.viewTreeObserver.addOnGlobalLayoutListener {
        val rect = Rect()
        rootView.getWindowVisibleDisplayFrame(rect)
        val screenHeight = rootView.height
        val keyboardHeight = screenHeight - rect.bottom
        isKeyboardVisible = keyboardHeight > keyboardHeightThreshold
    }
}

override fun onSingleTapUp(e: MotionEvent?) {
    terminalView.requestFocus()
    // Only show keyboard if not already visible
    if (!isKeyboardVisible) {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(terminalView, InputMethodManager.SHOW_IMPLICIT)
    }
}
```

### Session Race Condition Fix (v39)
**Problem:** Multiple `post{}` calls updating terminal without synchronization caused race conditions.

**Solution:** Added debounced terminal updates via Handler:
```kotlin
private val uiHandler = Handler(Looper.getMainLooper())
private var pendingTerminalUpdate: Runnable? = null
private val TERMINAL_UPDATE_DELAY = 50L

private fun scheduleTerminalUpdate() {
    pendingTerminalUpdate?.let { uiHandler.removeCallbacks(it) }
    pendingTerminalUpdate = Runnable {
        updateTerminalSize()
        terminalView.postInvalidate()
    }
    uiHandler.postDelayed(pendingTerminalUpdate!!, TERMINAL_UPDATE_DELAY)
}
```

### New Components Added (v39)

| Component | Purpose |
|-----------|---------|
| **TermuxApplication** | App-wide lifecycle management, crash handler |
| **SettingsActivity** | Proper settings UI for termux.properties |
| **RunCommandService** | Tasker integration (com.termux.RUN_COMMAND intent) |
| **TermuxDocumentsProvider** | SAF file access from other apps |
| **TermuxFileReceiverActivity** | Receive shared files into ~/downloads |
| **ContentProvider** | File sharing via content://com.termux.files/ |

### termux.properties Support (v39)
Now loads settings from `~/.termux/termux.properties`:
- `fullscreen=true/false` - Toggle fullscreen mode
- `extra-keys-text-all-caps=true/false` - Extra keys capitalization
- `terminal-cursor-style=block/bar/underline` - Cursor appearance
- `terminal-transcript-rows=N` - Scrollback buffer size
- `back-key=escape/back` - Back button behavior
- `bell-character=ignore/vibrate/beep` - Bell behavior

### Full configChanges (v39)
AndroidManifest now has complete configChanges like real Termux:
```xml
android:configChanges="mcc|mnc|locale|touchscreen|keyboard|keyboardHidden|navigation|screenLayout|fontScale|uiMode|orientation|screenSize|smallestScreenSize|density"
```

### New Utility Scripts (v39)
- `termux-change-repo` - Repository management
- `termux-fix-shebang` - Fix script shebangs
- `termux-reset` - Reset Termux environment
- `termux-backup` - Backup home directory
- `termux-restore` - Restore from backup
- `termux-file-editor` - File editor launcher
- `termux-url-opener` - URL handler
- `termux-file-opener` - File handler
- `pkg-config` - Package config wrapper

---

## v38 Features

All v37 features plus **TermuxAm** - the custom activity manager that real Termux uses.

### TermuxAm: The Root Cause Fix (v38)
**Problem:** Even with TermuxUrlHandlerActivity (v33), the `am start` command from shell still didn't work. Testing showed that `am start -a android.intent.action.VIEW -d "https://google.com"` produced NO output at all in MobileCLI, but worked in real Termux showing "Starting: Intent..."

**Root Cause Discovery:**
Real Termux doesn't use the system `/system/bin/am` directly. It has a custom `am` command called **TermuxAm** that:
1. Is installed at `/usr/bin/am` (shadows the system command)
2. Uses `app_process` to run Java code with proper app permissions
3. Contains `com.termux.termuxam.Am` class that handles activity starts

**Investigation Method:**
```bash
# Found real Termux's am script
cat /data/data/com.termux/files/usr/bin/am

# Output:
#!/data/data/com.termux/files/usr/bin/sh
AM_APK_PATH="/data/data/com.termux/files/usr/libexec/termux-am/am.apk"
export CLASSPATH="$AM_APK_PATH"
unset LD_LIBRARY_PATH LD_PRELOAD
exec /system/bin/app_process -Xnoimage-dex2oat / com.termux.termuxam.Am "$@"
```

**Why System am Doesn't Work:**
When you run `/system/bin/am` from within an app's shell, Android treats it as a child process of the app. However, the activity manager service may not grant the same privileges to start activities. TermuxAm works around this by running Java code through `app_process` which gets proper permissions.

**v38 Solution:**
1. Copied `am.apk` (580KB) from real Termux to `app/src/main/assets/termux-am/am.apk`
2. Added `installTermuxAm()` function to BootstrapInstaller that:
   - Creates `/usr/libexec/termux-am/` directory
   - Copies am.apk to that directory
   - Creates `/usr/bin/am` wrapper script that uses `app_process`

**Key Code (am script):**
```bash
#!/data/data/com.termux/files/usr/bin/sh
AM_APK_PATH="/data/data/com.termux/files/usr/libexec/termux-am/am.apk"
export CLASSPATH="$AM_APK_PATH"
unset LD_LIBRARY_PATH LD_PRELOAD
exec /system/bin/app_process -Xnoimage-dex2oat / com.termux.termuxam.Am "$@"
```

**Key Insight:** The `app_process` binary is Android's way of spawning Java processes. By setting CLASSPATH to point to an APK/DEX file and calling `app_process`, we can run arbitrary Java code with proper app permissions. This is how Termux's activity manager commands actually work.

---

## v33 Features

All v32 features plus **TermuxUrlHandlerActivity** for proper URL opening.

### URL Opening Fix: Activity-Based Handler (v33)
**Problem:** Claude Code OAuth URL still wouldn't open browser. Pressing "1" to authenticate did nothing.

**Root Cause:** Android restricts starting activities from background context.
- Shell commands like `am start -a android.intent.action.VIEW` run in background context
- BroadcastReceivers also run in background context
- Android blocks or delays activity launches from background

**Why v27 Fix Wasn't Enough:**
v27 fixed the component path for TermuxOpenReceiver, but the receiver still couldn't reliably start activities because Android restricts background activity launches.

**v33 Solution:**
Created `TermuxUrlHandlerActivity` - a transparent Activity that:
1. Receives URL from shell via `am start -n com.termux/.TermuxUrlHandlerActivity --es url "..."`
2. Has foreground Activity context (allowed to start other activities)
3. Starts the browser with proper Intent flags
4. Finishes immediately

**Key Code:**
```kotlin
class TermuxUrlHandlerActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("url")
        if (url != null) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        }
        finish()  // Transparent pass-through
    }
}
```

**Updated Scripts:**
- `termux-open-url` - Now uses TermuxUrlHandlerActivity
- `termux-open` - Detects URLs vs files, uses Activity for URLs
- `xdg-open` - Wrapper around termux-open

**Key Insight:** Android has different permission levels for starting activities:
- Activity context: Can start any activity
- Service context: Restricted (needs special flags)
- BroadcastReceiver context: Very restricted
- Shell/am start: Background context (may be blocked)

The solution is to route URL opens through an Activity.

---

## v32 Features

All v31 features plus **TermuxService** for background operation and wake lock support.

---

## v27 Features

All v26 features plus proper URL opening that actually works.

### URL Opening Fix: TermuxOpenReceiver Component Path (v27)
**Problem:** Claude Code OAuth URL still wouldn't open browser even after v25 fix.

**Root Cause:** Component name mismatch
- Real Termux scripts broadcast to: `com.termux/com.termux.app.TermuxOpenReceiver`
- MobileCLI only had: `com.termux.TermuxApiReceiver` (wrong package path!)

**v27 Solution:**
1. Created new file: `app/src/main/java/com/termux/app/TermuxOpenReceiver.kt`
2. Class is in package `com.termux.app` (matches real Termux exactly)
3. Registered in AndroidManifest.xml as `.app.TermuxOpenReceiver`

**Key Code:**
```kotlin
package com.termux.app  // MUST be com.termux.app, not com.termux

class TermuxOpenReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val uri = intent.data ?: return
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }
}
```

**Key Insight:** Android BroadcastReceiver component names are EXACT. Scripts that broadcast to `com.termux/com.termux.app.TermuxOpenReceiver` MUST have a receiver at that exact package path.

---

## v32 Features (THE 100% MILESTONE)

All v31 features plus **TermuxService** for background operation and wake lock support.

### TermuxService: Background Operation (v32)
**Problem:** Sessions died when app went to background. No wake lock for overnight tasks.

**Root Cause:** MobileCLI was activity-only. Real Termux uses `TermuxService` - a foreground service that:
- Manages sessions independently of Activity lifecycle
- Acquires CPU wake lock to prevent sleep
- Acquires WiFi lock to keep network connected
- Shows persistent notification

**v32 Solution:**
1. Created `app/src/main/java/com/termux/app/TermuxService.kt` (297 lines)
2. Registered as foreground service in AndroidManifest.xml
3. Added `termux-wake-lock` and `termux-wake-unlock` scripts
4. MainActivity binds to service on startup

**Key Code:**
```kotlin
// TermuxService.kt - Wake lock handling
fun acquireWakeLock() {
    val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
    wakeLock = powerManager.newWakeLock(
        PowerManager.PARTIAL_WAKE_LOCK,
        "MobileCLI::TermuxWakeLock"
    ).apply {
        setReferenceCounted(false)
        acquire()
    }

    // Also acquire WiFi lock for network operations
    val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    wifiLock = wifiManager.createWifiLock(
        WifiManager.WIFI_MODE_FULL_HIGH_PERF,
        "MobileCLI::TermuxWifiLock"
    ).apply { acquire() }
}
```

**Shell Scripts:**
```bash
# termux-wake-lock - Keeps CPU awake for overnight tasks
am startservice -a "com.termux.service_wake_lock" \
    "com.termux/com.termux.app.TermuxService"

# termux-wake-unlock - Releases locks, allows sleep
am startservice -a "com.termux.service_wake_unlock" \
    "com.termux/com.termux.app.TermuxService"
```

**Key Insight:** For overnight Claude Code sessions or long-running tasks, you MUST call `termux-wake-lock` first. This prevents Android from killing the process or suspending network.

### Source Code (v32)
| File | Lines | Purpose |
|------|-------|---------|
| MainActivity.kt | 1,248 | Activity + terminal UI |
| BootstrapInstaller.kt | 1,558 | Bootstrap + 52 scripts |
| TermuxApiReceiver.kt | 1,548 | 50+ API handlers |
| TermuxOpenReceiver.kt | 112 | URL/file opening |
| **TermuxService.kt** | **297** | **Background + wake lock** |
| **TOTAL** | **4,763** | |

---

## v26 Features

All v25 features plus complete TERMUX_APP__* environment variables.

### Environment Variables Added (v26)
Based on deep comparison with real Termux source code (see TERMUX_COMPARISON.md):

```bash
# Now set (matching real Termux):
TERMUX_APP__PID
TERMUX_APP__UID
TERMUX_APP__PACKAGE_NAME
TERMUX_APP__VERSION_NAME
TERMUX_APP__VERSION_CODE
TERMUX_APP__TARGET_SDK
TERMUX_APP__USER_ID
TERMUX_APP__IS_DEBUGGABLE_BUILD
TERMUX_APP__APK_RELEASE
TERMUX_APP__PACKAGE_MANAGER
TERMUX_APP__PACKAGE_VARIANT
TERMUX_APP__FILES_DIR
ANDROID_STORAGE
```

### Documentation Added
- **TERMUX_COMPARISON.md** - Complete comparison of MobileCLI vs real Termux

---

## v25 Features

All v23 features plus proper URL opening for Claude Code OAuth.

### URL Opening Fix: am start directly (v25)
**Problem:** Claude Code OAuth URL wouldn't open browser automatically.

**What v24 tried:** Added `xdg-open`, `termux-open`, `sensible-browser` scripts using `am broadcast` to our receiver.

**Why v24 failed:** Android blocks/delays `startActivity()` calls from BroadcastReceivers in background context.

**What real Termux does:**
```bash
# termux-open-url - uses am start DIRECTLY
am start --user "$TERMUX__USER_ID" -a android.intent.action.VIEW -d "$@"
```

**v25 Solution:** Changed all scripts to use `am start` directly, exactly like real Termux:
```bash
# No broadcast, no receiver - direct activity launch
am start --user "$TERMUX__USER_ID" -a android.intent.action.VIEW -d "$URL"
```

**Key Insight:** The real Termux source code shows `termux-open-url` never uses broadcasts - it calls `am start` directly. Our receiver-based approach was fundamentally wrong.

---

## v23 Features

All v22 features with critical bug fix.

### Bug Fix: setBackgroundResource Crash
**Problem:** App crashed on launch with "this app has a bug" error.

**Root Cause:** In `updateDrawerSessionsList()`:
```kotlin
// WRONG - android.R.attr.* is an ATTRIBUTE, not a drawable resource
setBackgroundResource(android.R.attr.selectableItemBackground)  // CRASHES!
```

**Solution:**
```kotlin
// CORRECT - use setBackgroundColor directly
setBackgroundColor(if (index == currentSessionIndex) 0xFF2a2a2a.toInt() else 0x00000000.toInt())
```

**Lesson Learned:** `android.R.attr.*` values are attribute references (for use in XML themes), NOT resource IDs. Never pass them to `setBackgroundResource()`. For dynamic backgrounds, use `setBackgroundColor()` or resolve the attribute first.

---

## v22 Features

All v21 features plus:

1. **Text selection works** - Long-press now selects text like Termux
2. **Sessions list in drawer** - Swipe left to see all sessions listed
3. **≡ Menu button** - Added to extra keys row for Copy/Paste/More
4. **Scrollable drawer** - Supports all 10 sessions visible

### Text Selection
- Long-press and drag to select text
- System copy menu appears after selection
- Use ≡ button for Copy/Paste menu

---

## v21 Features

All v20 features plus:

1. **Multi-session support** - Up to 10 concurrent terminal sessions
2. **Session tabs** - Visual tabs appear when 2+ sessions are open
3. **Session switching** - Tap tabs to switch, long-press for options
4. **Kill Session** - Properly terminates session like Termux (press Enter to close)
5. **Settings > Sessions** - View all sessions, switch, or kill
6. **More Options updated** - Reset terminal, Kill session, New session all work
7. **Session persistence** - Sessions survive orientation changes

### Session Management
- **New Session**: Swipe left drawer > New Session (or More > New session)
- **Switch Session**: Tap session number in tab bar
- **Kill Session**: Long-press tab > Kill, or More > Kill session
- **View All**: Settings > Sessions

---

## v20 Features

All v19 features plus:

1. **Built-in Termux API** - No need for separate F-Droid Termux:API app
2. **termux-clipboard-get/set** - Read/write clipboard from shell
3. **termux-toast** - Show toast messages
4. **termux-vibrate** - Vibration control
5. **termux-battery-status** - Get battery info as JSON
6. **termux-notification** - Send notifications with -t title -c content
7. **termux-open-url** - Open URLs in browser
8. **termux-volume** - Get volume levels
9. **termux-wifi-connectioninfo** - Get WiFi connection info
10. **termux-brightness** - Get screen brightness
11. **termux-torch** - Toggle flashlight on/off
12. **termux-media-scan** - Trigger media scanner
13. **termux-setup-storage** - Create ~/storage symlinks
14. **termux-info** - Show app/device info

### How API Works
- Shell scripts in `/usr/bin/` send broadcasts to `TermuxApiReceiver`
- Receiver handles the API call and writes result to temp file
- Script reads result and outputs to stdout

---

## v19 Features

1. **Full-screen terminal** - Reflection-based font metrics for perfect sizing
2. **Pinch zoom** - Smooth text resizing with proper recalculation
3. **AI Environment Chooser** - First-launch dialog to install Claude/Gemini/Codex
4. **Swipe navigation** - DrawerLayout menu (swipe from left)
5. **Context menu** - Long-press for Copy/Paste/More options
6. **Ctrl+C working** - Auto-reset modifiers after keypress
7. **Session persistence** - Transcript saved on app stop
8. **Install AI Tools** - Accessible anytime from drawer menu

---

## Terminal Screen Sizing (THE v19 BREAKTHROUGH)

### The Problem (v15-v18)
Terminal text was cut off - only using part of the screen. The issue was **mismatch between calculated font size and actual rendered font size**.

### Why It Failed
```kotlin
// WRONG - Guessing font dimensions
val density = resources.displayMetrics.density
val fontHeightPx = (textSize * density).toInt()  // Our guess
val fontWidthPx = (fontHeightPx * 0.55f).toInt() // Our guess

// This gave wrong columns/rows because TerminalView uses DIFFERENT font metrics internally
```

### The Solution (v19)
**Use reflection to get the ACTUAL font metrics from TerminalView's internal renderer:**

```kotlin
// CORRECT - Get real font dimensions from the view
val rendererField = terminalView.javaClass.getDeclaredField("mRenderer")
rendererField.isAccessible = true
val renderer = rendererField.get(terminalView)

val fontWidthField = renderer.javaClass.getDeclaredField("mFontWidth")
fontWidthField.isAccessible = true
val fontWidthPx = (fontWidthField.get(renderer) as Number).toInt()

val fontHeightField = renderer.javaClass.getDeclaredField("mFontLineSpacing")
fontHeightField.isAccessible = true
val fontHeightPx = (fontHeightField.get(renderer) as Number).toInt()

// Now columns/rows match what the view actually renders
val columns = terminalView.width / fontWidthPx
val rows = terminalView.height / fontHeightPx
session?.updateSize(columns, rows)
```

### Key Insight
The TerminalView library has its own font rendering logic. When you call `setTextSize()`, it calculates internal metrics (`mFontWidth`, `mFontLineSpacing`) that may differ from naive calculations. **Always get the actual values from the view itself.**

### Fallback (if reflection fails)
```kotlin
if (fontWidthPx <= 0 || fontHeightPx <= 0) {
    val density = resources.displayMetrics.density
    fontHeightPx = (currentTextSize * density * 1.2f).toInt()
    fontWidthPx = (currentTextSize * density * 0.6f).toInt()
}
```

---

## Legal & Licensing

### Original Code (Our IP)
- MainActivity.kt - 100% original
- BootstrapInstaller.kt - 100% original
- All XML layouts - 100% original
- System prompts - 100% original

### Third-Party (Licensed)
| Component | License | Commercial OK? |
|-----------|---------|----------------|
| terminal-view | Apache 2.0 | Yes (with attribution) |
| terminal-emulator | Apache 2.0 | Yes (with attribution) |
| Bootstrap packages | GPL-3.0 | Downloaded at runtime |
| AndroidX | Apache 2.0 | Yes |

### Package Name Requirement
`com.termux` is used due to hardcoded RUNPATH in Termux binaries. This is a technical requirement, not brand impersonation. Users see "MobileCLI" as the app name.

---

## Key Lesson

When debugging, systematically compare against working Termux:
```bash
env | sort  # Compare environment
ls -la /data/data/com.termux/files/  # Compare structure
```

The HOME path bug was found by noticing real Termux has `/files/home/` while we had just `/files/`.

---

## Common Bugs and Fixes

### 1. setBackgroundResource Crash (v22→v23)
```kotlin
// WRONG - crashes app
setBackgroundResource(android.R.attr.selectableItemBackground)

// CORRECT
setBackgroundColor(0xFF2a2a2a.toInt())
```

### 2. HOME Directory Path (v1-v9→v10)
```kotlin
// WRONG - breaks npm, node, everything
val homeDir = filesDir  // /data/data/com.termux/files

// CORRECT
val homeDir = File(filesDir, "home")  // /data/data/com.termux/files/home
```

### 3. Terminal Screen Cutoff (v15-v18→v19)
```kotlin
// WRONG - guessing font size
val fontWidthPx = (textSize * density * 0.6f).toInt()

// CORRECT - use reflection to get actual font metrics
val rendererField = terminalView.javaClass.getDeclaredField("mRenderer")
```

### 4. Install Commands Not Executing (v15-v17)
```kotlin
// WRONG - indentation breaks bash
val cmd = """
    pkg update
    pkg install nodejs
""".trimIndent()

// CORRECT - single line
val cmd = "pkg update -y && pkg install nodejs -y\n"
```

### 5. Long-press Hijacking Text Selection (v21→v22)
```kotlin
// WRONG - prevents text selection
override fun onLongPress(event: MotionEvent?): Boolean {
    showContextMenu(event)
    return true  // Consumes event
}

// CORRECT - let terminal handle it
override fun onLongPress(event: MotionEvent?): Boolean {
    return false  // Let TerminalView handle text selection
}
```

### Development Workflow
1. **Always create NEW version numbers** - Don't overwrite existing APKs
2. **Test on device immediately** after build
3. **If crash occurs** - Check logcat or analyze recent code changes
4. **Never update versions in-place** - v21 stays v21, fixes go to v22, v23, etc.

---

## Documentation

- **Full story:** https://mobilecli.com/app-story.html
- **Website proof:** https://mobilecli.com/proof.html
- **GitHub:** https://github.com/MobileDevCLI

---

## The Achievement

This is the first documented case of:
1. An Android app built entirely on an Android phone
2. Using AI (Claude Code) for the entire development process
3. Where the resulting app can run the AI that built it
4. Creating a self-improving development loop

**Date of achievement:** January 5, 2026
