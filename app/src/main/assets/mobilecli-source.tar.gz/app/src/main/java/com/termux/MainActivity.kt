package com.termux

import android.app.AlertDialog
import android.util.Log
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.res.Configuration
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewTreeObserver
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.lifecycleScope
import com.termux.app.TermuxService
import com.termux.terminal.TerminalEmulator
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient
import com.termux.view.TerminalView
import com.termux.view.TerminalViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Properties

class MainActivity : AppCompatActivity(), TerminalViewClient, TerminalSessionClient {

    private lateinit var terminalView: TerminalView
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var bootstrapInstaller: BootstrapInstaller

    // TermuxService for background operation
    private var termuxService: TermuxService? = null
    private var serviceBound = false

    // Multi-session support
    private val sessions = mutableListOf<TerminalSession>()
    private var currentSessionIndex = 0
    private val maxSessions = 10

    // Flag to track if bootstrap is ready but waiting for service
    private var bootstrapReadyPendingSession = false

    // Service connection
    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val localBinder = binder as TermuxService.LocalBinder
            termuxService = localBinder.service
            termuxService?.setSessionClient(this@MainActivity)
            serviceBound = true

            // Try to restore sessions from service
            termuxService?.let { service ->
                val serviceSessions = service.getSessions()
                if (serviceSessions.isNotEmpty()) {
                    // Restore existing sessions from service
                    Log.i("MainActivity", "Restoring ${serviceSessions.size} sessions from service")
                    sessions.clear()
                    sessions.addAll(serviceSessions)
                    currentSessionIndex = 0
                    terminalView.attachSession(sessions[0])
                    updateSessionTabs()
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Restored ${sessions.size} session(s)", Toast.LENGTH_SHORT).show()
                    }
                } else if (bootstrapReadyPendingSession) {
                    // No sessions to restore, and bootstrap is ready - create new session
                    Log.i("MainActivity", "Service connected, no sessions to restore, creating new session")
                    createSession()
                }
            }
            bootstrapReadyPendingSession = false
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            termuxService = null
            serviceBound = false
        }
    }

    // Current session shortcut
    private val session: TerminalSession?
        get() = sessions.getOrNull(currentSessionIndex)

    private var isCtrlPressed = false
    private var isAltPressed = false

    // Text size settings - larger for readability
    private var currentTextSize = 28  // Good readable size
    private val minTextSize = 14
    private val maxTextSize = 56

    // Progress dialog components
    private var progressDialog: AlertDialog? = null
    private var progressBar: ProgressBar? = null
    private var progressText: TextView? = null

    // Keyboard state tracking (fixes keyboard lock-up bug)
    private var isKeyboardVisible = false
    private var keyboardHeightThreshold = 0

    // Handler for debouncing terminal updates (fixes race conditions)
    private val uiHandler = Handler(Looper.getMainLooper())
    private var pendingTerminalUpdate: Runnable? = null
    private val updateDebounceMs = 16L // One frame

    // URL opener - polls for URL requests from shell (v51 fix)
    private var urlWatcherRunnable: Runnable? = null
    private val urlWatchInterval = 500L // Check every 500ms

    // termux.properties support
    private var termuxProperties: Properties? = null
    private val propertiesFile: File
        get() = File(File(bootstrapInstaller.homeDir, ".termux"), "termux.properties")

    // ============================================
    // DEVELOPER MODE SYSTEM (v58)
    // ============================================
    private var developerModeEnabled = false
    private var versionTapCount = 0
    private var lastVersionTapTime = 0L
    private val VERSION_TAP_THRESHOLD = 7
    private val VERSION_TAP_TIMEOUT = 2000L // 2 seconds between taps

    // Setup overlay UI elements
    private var setupOverlay: android.widget.FrameLayout? = null
    private var setupProgressScreen: android.widget.LinearLayout? = null
    private var aiChoiceScreen: android.widget.ScrollView? = null
    private var setupStatus: TextView? = null
    private var setupProgress: ProgressBar? = null
    private var setupPercentage: TextView? = null
    private var setupStep: TextView? = null

    // AI choice tracking
    private var selectedAI: String? = null
    private val AI_CLAUDE = "claude"
    private val AI_GEMINI = "gemini"
    private val AI_CODEX = "codex"
    private val AI_NONE = "none"

    // Developer options drawer items
    private var devOptionsDivider: android.view.View? = null
    private var devOptionsHeader: TextView? = null
    private var devModeToggle: TextView? = null
    private var installDevToolsItem: TextView? = null
    private var versionText: TextView? = null

    // Preferences key
    private val PREFS_NAME = "MobileCLIPrefs"
    private val KEY_DEV_MODE = "developer_mode_enabled"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Start and bind to TermuxService for background operation
        startTermuxService()

        terminalView = findViewById(R.id.terminal_view)
        terminalView.setTerminalViewClient(this)
        terminalView.setTextSize(currentTextSize)

        drawerLayout = findViewById(R.id.drawer_layout)
        bootstrapInstaller = BootstrapInstaller(this)

        // Setup extra keys
        setupExtraKeys()
        updateModifierButtons() // Set initial visual state

        // Setup navigation drawer
        setupNavDrawer()

        // Setup keyboard visibility listener (fixes keyboard lock-up bug)
        setupKeyboardListener()

        // Setup back button to dismiss keyboard (like real Termux)
        setupBackButtonHandler()

        // Setup URL watcher - polls for URL open requests from shell (v51)
        setupUrlWatcher()

        // Load termux.properties
        loadTermuxProperties()

        // ============================================
        // DEVELOPER MODE INITIALIZATION (v58)
        // ============================================
        setupDeveloperMode()
        setupSetupOverlay()

        // Check and install bootstrap if needed
        checkBootstrap()
    }

    /**
     * Setup keyboard visibility detection using ViewTreeObserver.
     * This fixes the keyboard lock-up bug by tracking keyboard state.
     */
    private fun setupKeyboardListener() {
        val rootView = window.decorView.rootView
        keyboardHeightThreshold = resources.displayMetrics.heightPixels / 4

        rootView.viewTreeObserver.addOnGlobalLayoutListener {
            val rect = Rect()
            rootView.getWindowVisibleDisplayFrame(rect)
            val screenHeight = rootView.height
            val keyboardHeight = screenHeight - rect.bottom

            val wasVisible = isKeyboardVisible
            isKeyboardVisible = keyboardHeight > keyboardHeightThreshold

            // If keyboard state changed, update terminal size
            if (wasVisible != isKeyboardVisible) {
                scheduleTerminalUpdate()
            }
        }
    }

    /**
     * Setup back button to dismiss keyboard like real Termux.
     * Back button priority:
     * 1. If keyboard is visible -> hide keyboard
     * 2. If drawer is open -> close drawer
     * 3. Otherwise -> default behavior (minimize app)
     */
    private fun setupBackButtonHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    // First: hide keyboard if visible
                    isKeyboardVisible -> {
                        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                        imm.hideSoftInputFromWindow(terminalView.windowToken, 0)
                    }
                    // Second: close drawer if open
                    drawerLayout.isDrawerOpen(androidx.core.view.GravityCompat.START) -> {
                        drawerLayout.closeDrawer(androidx.core.view.GravityCompat.START)
                    }
                    // Otherwise: minimize app (don't finish, keep session alive)
                    else -> {
                        moveTaskToBack(true)
                    }
                }
            }
        })
    }

    // ============================================
    // DEVELOPER MODE FUNCTIONS (v58)
    // ============================================

    /**
     * Initialize developer mode system.
     * - Check for personal build marker file (auto-enables dev mode)
     * - Load saved state from SharedPreferences
     * - Setup 7-tap activation on version text
     * - Setup long-press activation on setup overlay
     * - Update UI based on mode
     */
    private fun setupDeveloperMode() {
        // Check for personal build marker file
        // If ~/.mobilecli_dev_mode exists, dev mode is default ON (for your testing)
        val personalBuildMarker = File(bootstrapInstaller.homeDir, ".mobilecli_dev_mode")
        val sdcardMarker = File("/sdcard/Download/.mobilecli_dev_mode")
        val isPersonalBuild = personalBuildMarker.exists() || sdcardMarker.exists()

        // Load saved developer mode state
        // BuildConfig.DEV_MODE_DEFAULT is true for dev flavor, false for user flavor
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        developerModeEnabled = if (isPersonalBuild) {
            // Personal build marker - always dev mode (unless explicitly disabled)
            val wasExplicitlyDisabled = prefs.getBoolean("dev_mode_disabled_explicitly", false)
            !wasExplicitlyDisabled
        } else {
            // Use BuildConfig default (true for dev APK, false for user APK)
            prefs.getBoolean(KEY_DEV_MODE, BuildConfig.DEV_MODE_DEFAULT)
        }

        // Get developer UI elements
        devOptionsDivider = findViewById(R.id.dev_options_divider)
        devOptionsHeader = findViewById(R.id.nav_dev_options_header)
        devModeToggle = findViewById(R.id.nav_dev_mode)
        installDevToolsItem = findViewById(R.id.nav_install_dev_tools)
        versionText = findViewById(R.id.nav_version)

        // Set version text
        versionText?.text = "Version 1.7.1 (v66)"

        // Setup 7-tap activation on version text (like Android Developer Options)
        versionText?.setOnClickListener {
            val currentTime = System.currentTimeMillis()

            if (currentTime - lastVersionTapTime > VERSION_TAP_TIMEOUT) {
                versionTapCount = 0
            }

            versionTapCount++
            lastVersionTapTime = currentTime

            when {
                developerModeEnabled -> {
                    Toast.makeText(this, "Developer mode is already enabled", Toast.LENGTH_SHORT).show()
                }
                versionTapCount >= VERSION_TAP_THRESHOLD -> {
                    enableDeveloperMode()
                    versionTapCount = 0
                }
                versionTapCount >= 4 -> {
                    val remaining = VERSION_TAP_THRESHOLD - versionTapCount
                    Toast.makeText(this, "You are $remaining steps away from developer mode", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Setup developer mode toggle click
        devModeToggle?.setOnClickListener {
            toggleDeveloperMode()
        }

        // Setup install dev tools click
        installDevToolsItem?.setOnClickListener {
            drawerLayout.closeDrawers()
            runInstallDevTools()
        }

        // Update UI based on current mode
        updateDeveloperModeUI()
    }

    /**
     * Enable developer mode.
     */
    private fun enableDeveloperMode() {
        developerModeEnabled = true
        saveDeveloperModeState()
        updateDeveloperModeUI()
        Toast.makeText(this, "Developer mode enabled!", Toast.LENGTH_LONG).show()
    }

    /**
     * Toggle developer mode on/off.
     */
    private fun toggleDeveloperMode() {
        developerModeEnabled = !developerModeEnabled
        saveDeveloperModeState()
        updateDeveloperModeUI()
        val status = if (developerModeEnabled) "enabled" else "disabled"
        Toast.makeText(this, "Developer mode $status", Toast.LENGTH_SHORT).show()
    }

    /**
     * Save developer mode state to SharedPreferences.
     */
    private fun saveDeveloperModeState() {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_DEV_MODE, developerModeEnabled).apply()
    }

    /**
     * Update UI elements based on developer mode state.
     * NOTE: Dev mode toggle is ALWAYS visible for easy access (v61 improvement).
     * Only the extra dev features are hidden when dev mode is off.
     */
    private fun updateDeveloperModeUI() {
        // Dev mode toggle is ALWAYS visible for easy access
        devModeToggle?.visibility = android.view.View.VISIBLE
        devModeToggle?.text = if (developerModeEnabled) "⚙ Developer Mode: ON" else "⚙ Developer Mode: OFF"

        // Extra dev features only visible when dev mode is ON
        val extraVisibility = if (developerModeEnabled) android.view.View.VISIBLE else android.view.View.GONE
        devOptionsDivider?.visibility = extraVisibility
        devOptionsHeader?.visibility = extraVisibility
        installDevToolsItem?.visibility = extraVisibility
    }

    /**
     * Run the install-dev-tools script.
     */
    private fun runInstallDevTools() {
        session?.write("install-dev-tools\n")
        Toast.makeText(this, "Running install-dev-tools...", Toast.LENGTH_SHORT).show()
    }

    /**
     * Setup the clean setup overlay for user mode.
     */
    private fun setupSetupOverlay() {
        setupOverlay = findViewById(R.id.setup_overlay)
        setupProgressScreen = findViewById(R.id.setup_progress_screen)
        aiChoiceScreen = findViewById(R.id.ai_choice_screen)
        setupStatus = findViewById(R.id.setup_status)
        setupProgress = findViewById(R.id.setup_progress)
        setupPercentage = findViewById(R.id.setup_percentage)
        setupStep = findViewById(R.id.setup_step)

        // Setup AI card click handlers
        setupAICardClickHandlers()

        // Setup long-press on dev mode trigger (top-right corner during setup)
        val devModeTrigger: android.view.View? = findViewById(R.id.dev_mode_trigger)
        devModeTrigger?.setOnLongClickListener {
            if (!developerModeEnabled) {
                enableDeveloperMode()
                // Show terminal during setup if dev mode is enabled
                hideSetupOverlay()
            }
            true
        }
    }

    /**
     * Setup click handlers for AI choice cards.
     */
    private fun setupAICardClickHandlers() {
        findViewById<android.widget.LinearLayout>(R.id.ai_card_claude)?.setOnClickListener {
            onAISelected(AI_CLAUDE)
        }
        findViewById<android.widget.LinearLayout>(R.id.ai_card_gemini)?.setOnClickListener {
            onAISelected(AI_GEMINI)
        }
        findViewById<android.widget.LinearLayout>(R.id.ai_card_codex)?.setOnClickListener {
            onAISelected(AI_CODEX)
        }
        findViewById<android.widget.LinearLayout>(R.id.ai_card_none)?.setOnClickListener {
            onAISelected(AI_NONE)
        }
    }

    /**
     * Handle AI selection from choice screen.
     */
    private fun onAISelected(ai: String) {
        selectedAI = ai

        // Save selection
        val prefs = getSharedPreferences("mobilecli", Context.MODE_PRIVATE)
        prefs.edit().putString("selected_ai", ai).putBoolean("ai_setup_complete", true).apply()

        if (ai == AI_NONE) {
            // Skip AI installation, go straight to terminal
            hideSetupOverlay()
            createSessionOrDefer()
            Toast.makeText(this, "Terminal ready! Install AI tools anytime from settings.", Toast.LENGTH_LONG).show()
        } else {
            // Show progress screen and install selected AI
            showProgressScreenForAI(ai)
            installSelectedAI(ai)
        }
    }

    /**
     * Show AI choice screen (Stage 2).
     */
    private fun showAIChoiceScreen() {
        runOnUiThread {
            setupProgressScreen?.visibility = android.view.View.GONE
            aiChoiceScreen?.visibility = android.view.View.VISIBLE
        }
    }

    /**
     * Show progress screen for AI installation (Stage 3).
     */
    private fun showProgressScreenForAI(ai: String) {
        runOnUiThread {
            aiChoiceScreen?.visibility = android.view.View.GONE
            setupProgressScreen?.visibility = android.view.View.VISIBLE

            val aiName = when (ai) {
                AI_CLAUDE -> "Claude Code"
                AI_GEMINI -> "Gemini CLI"
                AI_CODEX -> "Codex CLI"
                else -> "AI Tools"
            }
            updateSetupProgress(0, "Installing $aiName...")
        }
    }

    /**
     * Install selected AI tool and auto-launch when complete.
     * ERROR INVISIBILITY: Users never see technical errors.
     * - Errors are logged but not shown
     * - Auto-retry on failure
     * - Friendly messages only
     */
    private fun installSelectedAI(ai: String) {
        lifecycleScope.launch(Dispatchers.IO) {
            var retryCount = 0
            val maxRetries = 2

            while (retryCount <= maxRetries) {
                try {
                    // Create session first if needed
                    withContext(Dispatchers.Main) {
                        if (sessions.isEmpty()) {
                            createSessionOrDefer()
                        }
                    }

                    // Wait for session to be ready
                    delay(1000)

                    val (packageName, installCmd, launchCmd) = when (ai) {
                        AI_CLAUDE -> Triple(
                            "Claude Code",
                            "pkg update -y 2>/dev/null && pkg install -y nodejs 2>/dev/null && npm install -g @anthropic-ai/claude-code 2>/dev/null",
                            "claude"
                        )
                        AI_GEMINI -> Triple(
                            "Gemini CLI",
                            "pkg update -y 2>/dev/null && pkg install -y nodejs 2>/dev/null && npm install -g @anthropic-ai/gemini-cli 2>/dev/null",
                            "gemini"
                        )
                        AI_CODEX -> Triple(
                            "Codex CLI",
                            "pkg update -y 2>/dev/null && pkg install -y nodejs 2>/dev/null && npm install -g @openai/codex 2>/dev/null",
                            "codex"
                        )
                        else -> Triple("", "", "")
                    }

                    if (installCmd.isEmpty()) {
                        withContext(Dispatchers.Main) {
                            hideSetupOverlay()
                        }
                        return@launch
                    }

                    // Update progress with retry info if needed
                    withContext(Dispatchers.Main) {
                        if (retryCount > 0) {
                            updateSetupProgress(5, "Please wait...")
                        } else {
                            updateSetupProgress(10, "Updating packages...")
                        }
                    }

                    // Run installation in background
                    // 2>/dev/null suppresses error output so users don't see it
                    val fullCmd = "$installCmd\n"

                    withContext(Dispatchers.Main) {
                        session?.write(fullCmd.toByteArray(Charsets.UTF_8), 0, fullCmd.toByteArray(Charsets.UTF_8).size)
                    }

                    // Progress animation while installation runs
                    val progressSteps = listOf(
                        15 to "Checking network...",
                        25 to "Downloading packages...",
                        40 to "Installing Node.js...",
                        55 to "Downloading $packageName...",
                        70 to "Installing $packageName...",
                        85 to "Configuring...",
                        95 to "Almost ready..."
                    )

                    for ((p, msg) in progressSteps) {
                        delay(3500) // Smooth progress
                        withContext(Dispatchers.Main) {
                            updateSetupProgress(p, msg)
                        }
                    }

                    // Wait for installation to complete
                    delay(5000)

                    withContext(Dispatchers.Main) {
                        updateSetupProgress(100, "Ready!")
                        delay(500)

                        // v64: Clear terminal, hide overlay, then launch
                        val clearCmd = "clear\n"
                        session?.write(clearCmd.toByteArray(Charsets.UTF_8), 0, clearCmd.length)
                        delay(300)

                        hideSetupOverlay()

                        delay(100)
                        if (launchCmd.isNotEmpty()) {
                            val cmd = "$launchCmd\n"
                            session?.write(cmd.toByteArray(Charsets.UTF_8), 0, cmd.length)
                        }
                    }

                    // Success - exit loop
                    return@launch

                } catch (e: Exception) {
                    Log.e("MainActivity", "AI installation attempt ${retryCount + 1} failed: ${e.message}")
                    retryCount++

                    if (retryCount <= maxRetries) {
                        // Silent retry
                        withContext(Dispatchers.Main) {
                            updateSetupProgress(5, "Please wait...")
                        }
                        delay(2000)
                    }
                }
            }

            // All retries exhausted - show FRIENDLY message (never technical error)
            withContext(Dispatchers.Main) {
                hideSetupOverlay()
                createSessionOrDefer()

                val aiName = when (ai) {
                    AI_CLAUDE -> "Claude"
                    AI_GEMINI -> "Gemini"
                    AI_CODEX -> "Codex"
                    else -> "AI"
                }

                // Friendly message - user doesn't know there was an error
                Toast.makeText(
                    this@MainActivity,
                    "Ready! Type '$ai' to start $aiName when download finishes.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    /**
     * Show error appropriately based on mode.
     * Developer mode: Show technical error
     * User mode: Show friendly message only
     */
    private fun showErrorSmart(technicalError: String, friendlyMessage: String) {
        if (developerModeEnabled) {
            showError(technicalError)
        } else {
            Toast.makeText(this, friendlyMessage, Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Show the clean setup overlay (user mode).
     */
    private fun showSetupOverlay() {
        if (!developerModeEnabled) {
            runOnUiThread {
                setupOverlay?.visibility = android.view.View.VISIBLE
                terminalView.visibility = android.view.View.GONE
            }
        }
    }

    /**
     * Hide the setup overlay and show terminal.
     */
    private fun hideSetupOverlay() {
        runOnUiThread {
            setupOverlay?.visibility = android.view.View.GONE
            terminalView.visibility = android.view.View.VISIBLE
        }
    }

    /**
     * Update the setup overlay progress.
     */
    private fun updateSetupProgress(progress: Int, status: String) {
        runOnUiThread {
            setupProgress?.progress = progress
            setupPercentage?.text = "$progress%"
            setupStatus?.text = status

            // Show step detail for certain progress points
            val step = when {
                progress < 20 -> "Preparing environment..."
                progress < 40 -> "Extracting packages..."
                progress < 60 -> "Setting up shell..."
                progress < 80 -> "Configuring AI tools..."
                progress < 95 -> "Almost ready..."
                else -> "Complete!"
            }
            setupStep?.text = step
        }
    }

    /**
     * Setup URL watcher - polls for URL open requests from shell.
     * This is the v51 fix that ACTUALLY WORKS because the Activity itself
     * opens the URL, not a background process.
     *
     * Shell writes URL to: ~/.termux/url_to_open
     * Activity reads it, deletes it, and opens the URL
     */
    private fun setupUrlWatcher() {
        val urlFile = File(File(bootstrapInstaller.homeDir, ".termux"), "url_to_open")

        urlWatcherRunnable = object : Runnable {
            override fun run() {
                try {
                    if (urlFile.exists()) {
                        val url = urlFile.readText().trim()
                        urlFile.delete()

                        if (url.isNotEmpty()) {
                            Log.i("MainActivity", "URL watcher: Opening URL: $url")
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

                                // v52: Use PendingIntent for clean identity
                                val flags = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                                    android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
                                } else {
                                    android.app.PendingIntent.FLAG_UPDATE_CURRENT
                                }
                                val pendingIntent = android.app.PendingIntent.getActivity(
                                    this@MainActivity, 0, intent, flags
                                )
                                pendingIntent.send()
                                Log.i("MainActivity", "URL watcher: PendingIntent sent successfully")
                            } catch (e: Exception) {
                                Log.e("MainActivity", "URL watcher: Failed to open URL", e)
                                runOnUiThread {
                                    Toast.makeText(this@MainActivity, "Failed to open: $url", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e("MainActivity", "URL watcher error", e)
                }

                // Schedule next check
                uiHandler.postDelayed(this, urlWatchInterval)
            }
        }

        // Start the watcher
        uiHandler.postDelayed(urlWatcherRunnable!!, urlWatchInterval)
        Log.i("MainActivity", "URL watcher started, checking every ${urlWatchInterval}ms")
    }

    /**
     * Load and parse termux.properties file.
     * Supports key settings from real Termux.
     */
    private fun loadTermuxProperties() {
        termuxProperties = Properties()
        try {
            if (propertiesFile.exists()) {
                propertiesFile.inputStream().use { stream ->
                    termuxProperties?.load(stream)
                }
                applyTermuxProperties()
            }
        } catch (e: Exception) {
            android.util.Log.w("MobileCLI", "Failed to load termux.properties: ${e.message}")
        }
    }

    /**
     * Apply settings from termux.properties.
     */
    private fun applyTermuxProperties() {
        termuxProperties?.let { props ->
            // Bell behavior
            val bellBehavior = props.getProperty("bell-character", "vibrate")
            // Store for use in onBell()

            // Fullscreen mode
            val useFullscreen = props.getProperty("fullscreen", "false")
            if (useFullscreen == "true") {
                window.decorView.systemUiVisibility = (
                    android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
            }

            // Terminal cursor style
            val cursorStyle = props.getProperty("terminal-cursor-style", "block")
            // Applied in getTerminalCursorStyle()

            // Back key behavior
            val backKey = props.getProperty("back-key", "back")
            // Store for use in key handling
        }
    }

    /**
     * Debounced terminal update to prevent race conditions.
     */
    private fun scheduleTerminalUpdate() {
        pendingTerminalUpdate?.let { uiHandler.removeCallbacks(it) }
        pendingTerminalUpdate = Runnable {
            updateTerminalSize()
            terminalView.onScreenUpdated()
        }
        uiHandler.postDelayed(pendingTerminalUpdate!!, updateDebounceMs)
    }

    private fun startTermuxService() {
        val serviceIntent = Intent(this, TermuxService::class.java)
        startService(serviceIntent)
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun checkBootstrap() {
        if (bootstrapInstaller.isInstalled()) {
            // Bootstrap ready, verify permissions and start terminal
            bootstrapInstaller.verifyAndFix()

            // Check if AI setup is needed
            if (isAISetupNeeded()) {
                // Show clean UI in user mode, dialog in dev mode
                if (developerModeEnabled) {
                    showSetupDialog("Preparing AI environment...")
                } else {
                    showSetupOverlay()
                    updateSetupProgress(70, "Configuring AI tools...")
                }
                runAISetup()
            } else {
                createSessionOrDefer()
            }
        } else {
            // Need to install bootstrap first
            // Show clean UI in user mode, dialog in dev mode
            if (developerModeEnabled) {
                showProgressDialog()
            } else {
                showSetupOverlay()
                updateSetupProgress(0, "Setting up your environment...")
            }
            installBootstrap()
        }
    }

    /**
     * Create a session, or defer to service connection if not yet bound.
     * This ensures we don't create a new session if the service has existing sessions to restore.
     */
    private fun createSessionOrDefer() {
        if (serviceBound && termuxService != null) {
            // Service is already bound - check if it has sessions
            val serviceSessions = termuxService?.getSessions() ?: emptyList()
            if (serviceSessions.isNotEmpty() && sessions.isEmpty()) {
                // Restore from service
                Log.i("MainActivity", "Creating session: restoring from service instead")
                sessions.addAll(serviceSessions)
                currentSessionIndex = 0
                terminalView.attachSession(sessions[0])
                updateSessionTabs()
            } else if (sessions.isEmpty()) {
                // No sessions anywhere, create new
                createSession()
            }
            // else: sessions already exist, don't create new one
        } else {
            // Service not bound yet - defer session creation
            Log.i("MainActivity", "Deferring session creation until service connects")
            bootstrapReadyPendingSession = true
        }
    }

    private fun isAISetupNeeded(): Boolean {
        val setupMarker = File(bootstrapInstaller.homeDir, ".mobilecli/.setup_complete")
        return !setupMarker.exists()
    }

    private fun isClaudeInstalled(): Boolean {
        val claudeBin = File(bootstrapInstaller.binDir, "claude")
        val nodeBin = File(bootstrapInstaller.binDir, "node")
        return claudeBin.exists() && nodeBin.exists()
    }

    private fun checkAndOfferAISetup() {
        val prefs = getSharedPreferences("mobilecli", Context.MODE_PRIVATE)
        val hasSetup = prefs.getBoolean("ai_setup_complete", false)

        if (!hasSetup) {
            terminalView.postDelayed({
                showAIChooserDialog()
            }, 1000)
        }
    }

    private fun showAIChooserDialog() {
        val prefs = getSharedPreferences("mobilecli", Context.MODE_PRIVATE)

        val options = arrayOf(
            "Claude Code (Recommended)",
            "Google Gemini CLI",
            "OpenAI Codex CLI",
            "All AI Tools",
            "None - Basic Terminal"
        )

        AlertDialog.Builder(this)
            .setTitle("Welcome to MobileCLI!")
            .setIcon(android.R.drawable.ic_dialog_info)
            .setSingleChoiceItems(options, 0, null)
            .setPositiveButton("Install") { dialog, _ ->
                val selected = (dialog as AlertDialog).listView.checkedItemPosition
                prefs.edit().putBoolean("ai_setup_complete", true).apply()

                when (selected) {
                    0 -> installAI("claude")
                    1 -> installAI("gemini")
                    2 -> installAI("codex")
                    3 -> installAI("all")
                    4 -> {
                        Toast.makeText(this, "Basic terminal ready!", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Skip") { _, _ ->
                prefs.edit().putBoolean("ai_setup_complete", true).apply()
                Toast.makeText(this, "You can install AI tools later from Settings", Toast.LENGTH_LONG).show()
            }
            .setCancelable(false)
            .show()
    }

    private fun installAI(tool: String) {
        // Offer Quick Install (auto) or Manual (step-by-step)
        val (title, autoCmd, manualSteps) = when (tool) {
            "claude" -> Triple(
                "Install Claude Code",
                "pkg update -y && pkg upgrade -y && pkg install nodejs-lts -y && npm install -g @anthropic-ai/claude-code && echo '\\n✓ Done! Type: claude'\n",
                "1. pkg update && pkg upgrade\n2. pkg install nodejs-lts\n3. npm install -g @anthropic-ai/claude-code\n4. claude"
            )
            "gemini" -> Triple(
                "Install Gemini CLI",
                "pkg update -y && pkg upgrade -y && pkg install nodejs-lts -y && npm install -g gemini-cli && echo '\\n✓ Done! Type: gemini'\n",
                "1. pkg update && pkg upgrade\n2. pkg install nodejs-lts\n3. npm install -g gemini-cli\n4. gemini"
            )
            "codex" -> Triple(
                "Install Codex CLI",
                "pkg update -y && pkg upgrade -y && pkg install nodejs-lts -y && npm install -g @openai/codex && echo '\\n✓ Done! Type: codex'\n",
                "1. pkg update && pkg upgrade\n2. pkg install nodejs-lts\n3. npm install -g @openai/codex\n4. codex"
            )
            "all" -> Triple(
                "Install All AI Tools",
                "pkg update -y && pkg upgrade -y && pkg install nodejs-lts -y && npm install -g @anthropic-ai/claude-code && npm install -g gemini-cli && npm install -g @openai/codex && echo '\\n✓ All AI tools installed!'\n",
                "1. pkg update && pkg upgrade\n2. pkg install nodejs-lts\n3. npm install -g @anthropic-ai/claude-code\n4. npm install -g gemini-cli\n5. npm install -g @openai/codex"
            )
            else -> Triple("", "", "")
        }

        if (title.isNotEmpty()) {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage("Choose installation method:")
                .setPositiveButton("Quick Install") { _, _ ->
                    // Auto-execute with -y flags
                    session?.write(autoCmd.toByteArray(Charsets.UTF_8), 0, autoCmd.toByteArray(Charsets.UTF_8).size)
                    Toast.makeText(this, "Installing... please wait", Toast.LENGTH_LONG).show()
                }
                .setNeutralButton("Manual") { _, _ ->
                    // Show step-by-step instructions
                    AlertDialog.Builder(this)
                        .setTitle("Manual Installation")
                        .setMessage("Run these commands:\n\n$manualSteps\n\nPress Y when prompted.")
                        .setPositiveButton("OK") { _, _ ->
                            terminalView.requestFocus()
                            val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                            imm.showSoftInput(terminalView, 0)
                        }
                        .show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun showSetupDialog(message: String) {
        val view = layoutInflater.inflate(R.layout.dialog_progress, null)
        progressBar = view.findViewById(R.id.progress_bar)
        progressText = view.findViewById(R.id.progress_text)
        progressText?.text = message

        progressDialog = AlertDialog.Builder(this)
            .setTitle("MobileCLI")
            .setView(view)
            .setCancelable(false)
            .create()
        progressDialog?.show()
    }

    private fun runAISetup() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val homeDir = bootstrapInstaller.homeDir
                val configDir = File(homeDir, ".mobilecli")
                configDir.mkdirs()

                // Create the secret system prompt
                withContext(Dispatchers.Main) {
                    progressText?.text = "Setting up AI configuration..."
                    progressBar?.progress = 20
                    if (!developerModeEnabled) {
                        updateSetupProgress(80, "Configuring AI assistant...")
                    }
                }

                createSystemPrompt()

                withContext(Dispatchers.Main) {
                    progressText?.text = "Configuration complete!"
                    progressBar?.progress = 100
                    if (!developerModeEnabled) {
                        updateSetupProgress(95, "Almost ready...")
                    }
                }

                // Mark AI config as done (but not AI choice)
                File(configDir, ".setup_complete").writeText("v1\n${System.currentTimeMillis()}")

                delay(500)

                withContext(Dispatchers.Main) {
                    progressDialog?.dismiss()

                    // Check if user already chose an AI previously
                    val prefs = getSharedPreferences("mobilecli", Context.MODE_PRIVATE)
                    val hasChosenAI = prefs.getBoolean("ai_setup_complete", false)

                    if (hasChosenAI) {
                        // v64: Hide overlay FIRST, then create session
                        hideSetupOverlay()
                        createSessionOrDefer()

                        // Auto-launch their chosen AI if it's installed
                        val chosenAI = prefs.getString("selected_ai", null)
                        if (chosenAI != null && chosenAI != AI_NONE) {
                            // v64: 1500ms delay, not 500
                            terminalView.postDelayed({
                                val launchCmd = when (chosenAI) {
                                    AI_CLAUDE -> "claude"
                                    AI_GEMINI -> "gemini"
                                    AI_CODEX -> "codex"
                                    else -> null
                                }
                                if (launchCmd != null && isAIInstalled(chosenAI)) {
                                    val cmd = "$launchCmd\n"
                                    session?.write(cmd.toByteArray(Charsets.UTF_8), 0, cmd.length)
                                }
                            }, 1500)
                        }
                    } else if (!developerModeEnabled) {
                        // First time - show AI choice screen (user mode)
                        showAIChoiceScreen()
                    } else {
                        // Developer mode - show dialog instead
                        hideSetupOverlay()
                        createSessionOrDefer()
                        showAIChooserDialog()
                    }
                }

            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    progressDialog?.dismiss()
                    hideSetupOverlay()
                    showError("AI setup failed: ${e.message}")
                }
            }
        }
    }

    /**
     * Check if an AI tool is installed.
     */
    private fun isAIInstalled(ai: String): Boolean {
        val binName = when (ai) {
            AI_CLAUDE -> "claude"
            AI_GEMINI -> "gemini"
            AI_CODEX -> "codex"
            else -> return false
        }
        return File(bootstrapInstaller.binDir, binName).exists()
    }

    private fun createSystemPrompt() {
        val homeDir = bootstrapInstaller.homeDir
        val configDir = File(homeDir, ".mobilecli")
        configDir.mkdirs()

        // Create the comprehensive system prompt
        val systemPrompt = """
# MobileCLI AI Environment - System Knowledge

## YOU ARE RUNNING IN MOBILECLI - A MOBILE AI DEVELOPMENT ENVIRONMENT

This is a Termux-compatible environment on Android. You have full terminal access.

## CRITICAL PATHS

### Phone Storage
- Screenshots: `/sdcard/DCIM/Screenshots/`
- Camera photos: `/sdcard/DCIM/Camera/`
- Downloads: `/sdcard/Download/`
- Documents: `/sdcard/Documents/`

### Environment
- HOME: `${'$'}HOME` = `/data/data/com.termux/files/home`
- PREFIX: `${'$'}PREFIX` = `/data/data/com.termux/files/usr`
- Binaries: `/data/data/com.termux/files/usr/bin`

## HOW TO VIEW IMAGES/SCREENSHOTS

Use the Read tool to view any image:
```
Read /sdcard/DCIM/Screenshots/Screenshot_*.jpg
```

List recent screenshots:
```bash
ls -lt /sdcard/DCIM/Screenshots/ | head -10
```

## PACKAGE MANAGEMENT

Install packages:
```bash
pkg install <package>
pkg update && pkg upgrade
```

Common packages: nodejs, python, git, openssh, curl, wget

## BUILDING ANDROID APPS

Android SDK location: `~/android-sdk`

Build APK:
```bash
cd <project>
./gradlew assembleDebug
```

Copy to Downloads for installation:
```bash
cp app/build/outputs/apk/debug/*.apk /sdcard/Download/
```

## GITHUB SETUP

```bash
pkg install git gh
gh auth login
git config --global user.name "Your Name"
git config --global user.email "your@email.com"
```

## VERCEL DEPLOYMENT

```bash
npm install -g vercel
vercel login
vercel --prod
```

## AI CLI TOOLS

- Claude Code: `claude`
- Gemini: `gemini`
- Codex: `codex`

## BEST PRACTICES

1. Always check screenshots when user mentions them
2. Build and test frequently
3. Copy APKs to /sdcard/Download/ for easy installation
4. Use pkg for system packages, npm for Node packages
5. The user is on mobile - keep responses concise

## REMEMBER

You are inside MobileCLI, a premium mobile development environment.
The user expects things to "just work" - be proactive and helpful.
""".trimIndent()

        // Write to hidden config directory
        File(configDir, "SYSTEM_PROMPT.md").writeText(systemPrompt)

        // Create symlink for Claude Code to find it
        val claudeMd = File(homeDir, "CLAUDE.md")
        if (!claudeMd.exists()) {
            claudeMd.writeText(systemPrompt)
        }
    }

    private fun showProgressDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_progress, null)
        progressBar = view.findViewById(R.id.progress_bar)
        progressText = view.findViewById(R.id.progress_text)

        progressDialog = AlertDialog.Builder(this)
            .setTitle("Setting up MobileCLI")
            .setView(view)
            .setCancelable(false)
            .create()
        progressDialog?.show()
    }

    private fun installBootstrap() {
        bootstrapInstaller.onProgress = { progress, message ->
            runOnUiThread {
                if (progress >= 0) {
                    // Update both dialog and overlay
                    progressBar?.progress = progress
                    progressText?.text = message

                    // Update setup overlay (for user mode)
                    if (!developerModeEnabled) {
                        updateSetupProgress(progress, message)
                    }
                } else {
                    progressDialog?.dismiss()
                    hideSetupOverlay()
                    showError(message)
                }
            }
        }

        lifecycleScope.launch(Dispatchers.IO) {
            val success = bootstrapInstaller.install()
            withContext(Dispatchers.Main) {
                progressDialog?.dismiss()
                if (success) {
                    // Now run AI setup
                    if (isAISetupNeeded()) {
                        if (developerModeEnabled) {
                            showSetupDialog("Preparing AI environment...")
                        } else {
                            updateSetupProgress(70, "Configuring AI tools...")
                        }
                        runAISetup()
                    } else {
                        hideSetupOverlay()
                        createSessionOrDefer()
                    }
                } else {
                    hideSetupOverlay()
                    showError("Bootstrap installation failed")
                }
            }
        }
    }

    private fun showError(message: String) {
        AlertDialog.Builder(this)
            .setTitle("Error")
            .setMessage(message)
            .setPositiveButton("Retry") { _, _ -> checkBootstrap() }
            .setNegativeButton("Exit") { _, _ -> finish() }
            .show()
    }

    private fun setupExtraKeys() {
        // Row 1 - Main controls
        findViewById<Button>(R.id.btn_esc).setOnClickListener { sendKey(27) }
        findViewById<Button>(R.id.btn_ctrl).setOnClickListener { isCtrlPressed = !isCtrlPressed; updateModifierButtons() }
        findViewById<Button>(R.id.btn_alt).setOnClickListener { isAltPressed = !isAltPressed; updateModifierButtons() }
        findViewById<Button>(R.id.btn_tab).setOnClickListener { sendKey(9) }
        findViewById<Button>(R.id.btn_home).setOnClickListener { sendSpecialKey("\u001b[H") }
        findViewById<Button>(R.id.btn_up).setOnClickListener { sendSpecialKey("\u001b[A") }
        findViewById<Button>(R.id.btn_end).setOnClickListener { sendSpecialKey("\u001b[F") }
        findViewById<Button>(R.id.btn_pgup).setOnClickListener { sendSpecialKey("\u001b[5~") }

        // Row 2 - Symbols and navigation
        findViewById<Button>(R.id.btn_dash).setOnClickListener { sendChar('-') }
        findViewById<Button>(R.id.btn_slash).setOnClickListener { sendChar('/') }
        findViewById<Button>(R.id.btn_backslash).setOnClickListener { sendChar('\\') }
        findViewById<Button>(R.id.btn_pipe).setOnClickListener { sendChar('|') }
        findViewById<Button>(R.id.btn_left).setOnClickListener { sendSpecialKey("\u001b[D") }
        findViewById<Button>(R.id.btn_down).setOnClickListener { sendSpecialKey("\u001b[B") }
        findViewById<Button>(R.id.btn_right).setOnClickListener { sendSpecialKey("\u001b[C") }
        findViewById<Button>(R.id.btn_pgdn).setOnClickListener { sendSpecialKey("\u001b[6~") }
        findViewById<Button>(R.id.btn_tilde).setOnClickListener { sendChar('~') }
        findViewById<Button>(R.id.btn_underscore).setOnClickListener { sendChar('_') }
        findViewById<Button>(R.id.btn_colon).setOnClickListener { sendChar(':') }
        findViewById<Button>(R.id.btn_quote).setOnClickListener { sendChar('"') }
        findViewById<Button>(R.id.btn_more).setOnClickListener { showMoreOptions() }
        findViewById<Button>(R.id.btn_more).setOnLongClickListener { showContextMenu(null); true }
    }

    private fun updateModifierButtons() {
        findViewById<Button>(R.id.btn_ctrl).alpha = if (isCtrlPressed) 1.0f else 0.5f
        findViewById<Button>(R.id.btn_alt).alpha = if (isAltPressed) 1.0f else 0.5f
    }

    private fun setupNavDrawer() {
        // New Session - adds a new session tab
        findViewById<TextView>(R.id.nav_new_session).setOnClickListener {
            drawerLayout.closeDrawers()
            if (sessions.size < maxSessions) {
                addNewSession()
                Toast.makeText(this, "Session ${sessions.size} created", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Maximum $maxSessions sessions reached", Toast.LENGTH_SHORT).show()
            }
        }

        // Settings - show settings dialog
        findViewById<TextView>(R.id.nav_settings).setOnClickListener {
            drawerLayout.closeDrawers()
            showSettingsDialog()
        }

        // Toggle Keyboard
        findViewById<TextView>(R.id.nav_keyboard).setOnClickListener {
            drawerLayout.closeDrawers()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.toggleSoftInput(0, 0)
        }

        // Text Size
        findViewById<TextView>(R.id.nav_text_size).setOnClickListener {
            drawerLayout.closeDrawers()
            showTextSizeDialog()
        }

        // Install AI Tools
        findViewById<TextView>(R.id.nav_install_ai).setOnClickListener {
            drawerLayout.closeDrawers()
            showAIChooserDialog()
        }

        // Help
        findViewById<TextView>(R.id.nav_help).setOnClickListener {
            drawerLayout.closeDrawers()
            showHelpDialog()
        }

        // About
        findViewById<TextView>(R.id.nav_about).setOnClickListener {
            drawerLayout.closeDrawers()
            showAboutDialog()
        }
    }

    private fun addNewSession() {
        val newSession = createNewTerminalSession()
        sessions.add(newSession)
        currentSessionIndex = sessions.size - 1
        terminalView.attachSession(newSession)
        terminalView.post {
            updateTerminalSize()
            terminalView.requestFocus()
        }
        updateSessionTabs()
    }

    private fun switchToSession(index: Int) {
        if (index >= 0 && index < sessions.size && index != currentSessionIndex) {
            currentSessionIndex = index
            terminalView.attachSession(sessions[index])
            terminalView.post {
                updateTerminalSize()
                terminalView.onScreenUpdated()
            }
            updateSessionTabs()
        }
    }

    private fun killCurrentSession() {
        if (sessions.isEmpty()) return

        val sessionToKill = session ?: return

        // Send exit message to terminal
        val exitMsg = "\r\n[Process completed - press Enter to close]\r\n"
        sessionToKill.write(exitMsg.toByteArray(), 0, exitMsg.length)

        // Mark session for removal on next key press
        sessionToKill.finishIfRunning()
    }

    private fun removeSession(index: Int) {
        if (sessions.size <= 1) {
            // Last session - create a new one instead
            sessions.clear()
            currentSessionIndex = 0
            addNewSession()
            return
        }

        sessions.removeAt(index)
        if (currentSessionIndex >= sessions.size) {
            currentSessionIndex = sessions.size - 1
        }
        terminalView.attachSession(sessions[currentSessionIndex])
        terminalView.post {
            updateTerminalSize()
            terminalView.onScreenUpdated()
        }
        updateSessionTabs()
    }

    private fun updateSessionTabs() {
        // Update top tab bar
        val tabsContainer = findViewById<android.widget.HorizontalScrollView>(R.id.session_tabs_container)
        val tabsLayout = findViewById<android.widget.LinearLayout>(R.id.session_tabs)

        if (tabsContainer != null && tabsLayout != null) {
            tabsLayout.removeAllViews()

            // Show tabs only if more than 1 session
            if (sessions.size > 1) {
                tabsContainer.visibility = android.view.View.VISIBLE

                sessions.forEachIndexed { index, _ ->
                    val tab = Button(this).apply {
                        text = "${index + 1}"
                        textSize = 12f
                        setTextColor(if (index == currentSessionIndex) 0xFF00FF00.toInt() else 0xFFFFFFFF.toInt())
                        setBackgroundColor(if (index == currentSessionIndex) 0xFF333333.toInt() else 0xFF1a1a1a.toInt())
                        setPadding(24, 8, 24, 8)
                        minimumWidth = 0
                        minWidth = 0

                        setOnClickListener { switchToSession(index) }
                        setOnLongClickListener {
                            showSessionOptions(index)
                            true
                        }
                    }
                    tabsLayout.addView(tab)
                }
            } else {
                tabsContainer.visibility = android.view.View.GONE
            }
        }

        // Update drawer sessions list
        updateDrawerSessionsList()
    }

    private fun updateDrawerSessionsList() {
        val sessionsList = findViewById<android.widget.LinearLayout>(R.id.sessions_list) ?: return
        sessionsList.removeAllViews()

        sessions.forEachIndexed { index, _ ->
            val sessionItem = TextView(this).apply {
                text = if (index == currentSessionIndex) "● Session ${index + 1} (active)" else "○ Session ${index + 1}"
                textSize = 16f
                setTextColor(if (index == currentSessionIndex) 0xFF4CAF50.toInt() else 0xFFFFFFFF.toInt())
                setPadding(24, 24, 24, 24)
                setBackgroundColor(if (index == currentSessionIndex) 0xFF2a2a2a.toInt() else 0x00000000.toInt())
                isClickable = true
                isFocusable = true

                setOnClickListener {
                    switchToSession(index)
                    drawerLayout.closeDrawers()
                }

                setOnLongClickListener {
                    showSessionOptionsInDrawer(index)
                    true
                }
            }
            sessionsList.addView(sessionItem)
        }

        // Show placeholder if no sessions
        if (sessions.isEmpty()) {
            val placeholder = TextView(this).apply {
                text = "No sessions"
                textSize = 14f
                setTextColor(0xFF666666.toInt())
                setPadding(24, 16, 24, 16)
            }
            sessionsList.addView(placeholder)
        }
    }

    private fun showSessionOptionsInDrawer(index: Int) {
        val options = arrayOf("Switch to session", "Kill session", "Rename session")
        AlertDialog.Builder(this)
            .setTitle("Session ${index + 1}")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        switchToSession(index)
                        drawerLayout.closeDrawers()
                    }
                    1 -> {
                        if (index == currentSessionIndex) {
                            killCurrentSession()
                        } else {
                            sessions[index].finishIfRunning()
                            removeSession(index)
                        }
                        drawerLayout.closeDrawers()
                    }
                    2 -> {
                        // Rename not implemented yet - just show toast
                        Toast.makeText(this, "Session names coming soon", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    private fun showSessionOptions(index: Int) {
        val options = arrayOf("Switch to session", "Kill session")
        AlertDialog.Builder(this)
            .setTitle("Session ${index + 1}")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> switchToSession(index)
                    1 -> {
                        if (index == currentSessionIndex) {
                            killCurrentSession()
                        } else {
                            sessions[index].finishIfRunning()
                            removeSession(index)
                        }
                    }
                }
            }
            .show()
    }

    private fun showSettingsDialog() {
        val options = arrayOf("Text Size", "Reset Terminal", "Kill Session", "New Session", "Sessions (${sessions.size}/$maxSessions)", "Clear Session History")
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showTextSizeDialog()
                    1 -> {
                        session?.let { s ->
                            s.reset()
                            terminalView.onScreenUpdated()
                            Toast.makeText(this, "Terminal reset", Toast.LENGTH_SHORT).show()
                        }
                    }
                    2 -> {
                        // Kill current session
                        killCurrentSession()
                    }
                    3 -> {
                        // New session
                        if (sessions.size < maxSessions) {
                            addNewSession()
                            Toast.makeText(this, "Session ${sessions.size} created", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this, "Maximum $maxSessions sessions reached", Toast.LENGTH_SHORT).show()
                        }
                    }
                    4 -> {
                        // Show sessions list
                        showSessionsDialog()
                    }
                    5 -> {
                        // Clear saved session data
                        val prefs = getSharedPreferences("mobilecli", Context.MODE_PRIVATE)
                        prefs.edit().remove("last_transcript").apply()
                        Toast.makeText(this, "Session history cleared", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    private fun showSessionsDialog() {
        if (sessions.isEmpty()) {
            Toast.makeText(this, "No sessions", Toast.LENGTH_SHORT).show()
            return
        }

        val sessionNames = sessions.mapIndexed { index, _ ->
            val marker = if (index == currentSessionIndex) " (current)" else ""
            "Session ${index + 1}$marker"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Sessions")
            .setItems(sessionNames) { _, which ->
                switchToSession(which)
            }
            .setNeutralButton("Kill Current") { _, _ ->
                killCurrentSession()
            }
            .setPositiveButton("New") { _, _ ->
                if (sessions.size < maxSessions) {
                    addNewSession()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showHelpDialog() {
        val help = """
            |Getting Started:
            |• Type commands and press Enter
            |• Swipe from left for menu
            |• Long-press for copy/paste
            |• Pinch to zoom text
            |
            |Useful Commands:
            |• pkg install <package>
            |• claude - Start Claude AI
            |• ls, cd, cat - File navigation
            |• git, npm, node - Dev tools
            |
            |Extra Keys:
            |• CTRL/ALT - Modifier keys (tap to toggle)
            |• ESC - Escape key
            |• TAB - Tab completion
            |• Arrows - Navigation
        """.trimMargin()

        AlertDialog.Builder(this)
            .setTitle("Help")
            .setMessage(help)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showAboutDialog() {
        AlertDialog.Builder(this)
            .setTitle("MobileCLI")
            .setMessage("Mobile AI Development Environment\n\nVersion 1.0\n\nA full terminal with AI capabilities.\n\nhttps://mobilecli.com")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun sendKey(keyCode: Int) {
        session?.write(byteArrayOf(keyCode.toByte()), 0, 1)
    }

    private fun sendSpecialKey(sequence: String) {
        session?.write(sequence.toByteArray(), 0, sequence.length)
    }

    private fun sendChar(c: Char) {
        var code = c.code
        if (isCtrlPressed && c.isLetter()) {
            code = c.uppercaseChar().code - 64
            isCtrlPressed = false
            updateModifierButtons()
        }
        session?.write(byteArrayOf(code.toByte()), 0, 1)
    }

    private fun createNewTerminalSession(): TerminalSession {
        val home = bootstrapInstaller.homeDir.absolutePath
        bootstrapInstaller.homeDir.mkdirs()

        val loginFile = File(bootstrapInstaller.binDir, "login")
        val bashFile = File(bootstrapInstaller.bashPath)
        val shFile = File(bootstrapInstaller.binDir, "sh")

        val shell: String
        val args: Array<String>

        if (loginFile.exists() && loginFile.canExecute()) {
            shell = loginFile.absolutePath
            args = arrayOf()
        } else if (bashFile.exists() && bashFile.canExecute()) {
            shell = bashFile.absolutePath
            args = arrayOf("--login")
        } else if (shFile.exists() && shFile.canExecute()) {
            shell = shFile.absolutePath
            args = arrayOf()
        } else {
            shell = "/system/bin/sh"
            args = arrayOf()
        }

        val env = bootstrapInstaller.getEnvironment()

        return try {
            TerminalSession(shell, home, args, env, 4000, this)
        } catch (e: Exception) {
            android.util.Log.e("MobileCLI", "Failed to create session", e)
            TerminalSession("/system/bin/sh", home, arrayOf(), env, 4000, this)
        }
    }

    private fun createSession() {
        val newSession = createNewTerminalSession()
        sessions.clear()
        sessions.add(newSession)
        currentSessionIndex = 0
        terminalView.attachSession(newSession)

        terminalView.post {
            updateTerminalSize()
            terminalView.requestFocus()
            updateSessionTabs()
            // Offer AI environment setup on first launch
            checkAndOfferAISetup()
        }
    }

    override fun onStop() {
        super.onStop()
        // Save transcript for session persistence
        saveTranscript()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Unbind from TermuxService but DON'T kill sessions
        // Sessions are now managed by TermuxService which keeps running
        if (serviceBound) {
            // Transfer sessions to service before unbinding
            termuxService?.let { service ->
                sessions.forEach { session ->
                    service.addSession(session)
                }
            }
            unbindService(serviceConnection)
            serviceBound = false
        }
        // DON'T kill sessions - let them persist in the service
        // The service keeps running as a foreground service
        // sessions.forEach { it.finishIfRunning() }
        // sessions.clear()
        Log.i("MainActivity", "Activity destroyed, sessions preserved in service")
    }

    private fun saveTranscript() {
        try {
            val transcript = session?.emulator?.screen?.getTranscriptText() ?: return
            if (transcript.isNotEmpty()) {
                val prefs = getSharedPreferences("mobilecli", Context.MODE_PRIVATE)
                prefs.edit().putString("last_transcript", transcript).apply()
            }
        } catch (e: Exception) {
            // Ignore save errors
        }
    }

    private fun restoreTranscript() {
        try {
            val prefs = getSharedPreferences("mobilecli", Context.MODE_PRIVATE)
            val saved = prefs.getString("last_transcript", null)
            if (!saved.isNullOrEmpty() && saved.length > 100) {
                // Show option to view previous session
                AlertDialog.Builder(this)
                    .setTitle("Previous Session")
                    .setMessage("Restore transcript from previous session?")
                    .setPositiveButton("Yes") { _, _ ->
                        session?.write("\n# Previous session transcript available\n# Use 'cat ~/.mobilecli/last_session.txt' to view\n".toByteArray(), 0, 80)
                        // Save to file for access
                        File(bootstrapInstaller.homeDir, ".mobilecli").mkdirs()
                        File(bootstrapInstaller.homeDir, ".mobilecli/last_session.txt").writeText(saved)
                    }
                    .setNegativeButton("No") { _, _ ->
                        // Clear old transcript
                        prefs.edit().remove("last_transcript").apply()
                    }
                    .show()
            }
        } catch (e: Exception) {
            // Ignore restore errors
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        terminalView.post {
            updateTerminalSize()
            terminalView.invalidate()
        }
    }

    private fun updateTerminalSize() {
        terminalView.post {
            if (terminalView.width > 0 && terminalView.height > 0 && session != null) {
                // Try to get actual font metrics from the TerminalView's renderer
                var fontWidthPx = 0
                var fontHeightPx = 0

                try {
                    // Access the mRenderer field to get actual font dimensions
                    val rendererField = terminalView.javaClass.getDeclaredField("mRenderer")
                    rendererField.isAccessible = true
                    val renderer = rendererField.get(terminalView)

                    if (renderer != null) {
                        val fontWidthField = renderer.javaClass.getDeclaredField("mFontWidth")
                        fontWidthField.isAccessible = true
                        fontWidthPx = (fontWidthField.get(renderer) as Number).toInt()

                        val fontHeightField = renderer.javaClass.getDeclaredField("mFontLineSpacing")
                        fontHeightField.isAccessible = true
                        fontHeightPx = (fontHeightField.get(renderer) as Number).toInt()
                    }
                } catch (e: Exception) {
                    android.util.Log.w("MobileCLI", "Could not get font metrics: ${e.message}")
                }

                // Fallback if reflection fails
                if (fontWidthPx <= 0 || fontHeightPx <= 0) {
                    val density = resources.displayMetrics.density
                    fontHeightPx = (currentTextSize * density * 1.2f).toInt().coerceAtLeast(1)
                    fontWidthPx = (currentTextSize * density * 0.6f).toInt().coerceAtLeast(1)
                }

                val newColumns = (terminalView.width / fontWidthPx).coerceIn(20, 500)
                val newRows = (terminalView.height / fontHeightPx).coerceIn(5, 200)

                session?.updateSize(newColumns, newRows)
                android.util.Log.i("MobileCLI", "Terminal: ${newColumns}x${newRows}, font: ${fontWidthPx}x${fontHeightPx}, view: ${terminalView.width}x${terminalView.height}")
            }
        }
    }

    // TerminalViewClient implementation
    override fun onScale(scale: Float): Float {
        if (scale < 0.9f || scale > 1.1f) {
            val delta = if (scale > 1f) 2 else -2
            val newSize = (currentTextSize + delta).coerceIn(minTextSize, maxTextSize)
            if (newSize != currentTextSize) {
                currentTextSize = newSize
                terminalView.setTextSize(currentTextSize)
                // Update terminal size after text size change
                terminalView.post {
                    updateTerminalSize()
                    terminalView.onScreenUpdated()
                }
            }
        }
        // Return 1.0f to indicate we've handled the scale and don't want default behavior
        return 1.0f
    }

    override fun onSingleTapUp(e: MotionEvent?) {
        terminalView.requestFocus()
        // Only show keyboard if not already visible (fixes keyboard lock-up bug)
        if (!isKeyboardVisible) {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(terminalView, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    override fun onLongPress(event: MotionEvent?): Boolean {
        // Return false to let TerminalView handle text selection
        // Context menu is available via drawer menu or extra keys
        return false
    }

    private fun showContextMenu(event: MotionEvent?) {
        val options = arrayOf("Copy", "Paste", "Select All", "More...")
        AlertDialog.Builder(this)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        // Copy - get transcript text
                        val text = session?.emulator?.screen?.getTranscriptText()
                        if (!text.isNullOrEmpty()) {
                            copyToClipboard(text)
                            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this, "Nothing to copy", Toast.LENGTH_SHORT).show()
                        }
                    }
                    1 -> {
                        // Paste
                        pasteFromClipboard()
                    }
                    2 -> {
                        // Select All - copy entire transcript
                        val text = session?.emulator?.screen?.getTranscriptText()
                        if (!text.isNullOrEmpty()) {
                            copyToClipboard(text)
                            Toast.makeText(this, "All text copied", Toast.LENGTH_SHORT).show()
                        }
                    }
                    3 -> {
                        // More options
                        showMoreOptions()
                    }
                }
            }
            .show()
    }

    private fun showMoreOptions() {
        val options = arrayOf("Copy All", "Paste", "New session", "Kill session", "Reset terminal", "Change text size", "Toggle keyboard", "About")
        AlertDialog.Builder(this)
            .setTitle("More Options")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        // Copy All - get entire transcript
                        val text = session?.emulator?.screen?.getTranscriptText()
                        if (!text.isNullOrEmpty()) {
                            copyToClipboard(text)
                            Toast.makeText(this, "All text copied to clipboard", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this, "Nothing to copy", Toast.LENGTH_SHORT).show()
                        }
                    }
                    1 -> {
                        // Paste from clipboard
                        pasteFromClipboard()
                        Toast.makeText(this, "Pasted", Toast.LENGTH_SHORT).show()
                    }
                    2 -> {
                        // New session
                        if (sessions.size < maxSessions) {
                            addNewSession()
                            Toast.makeText(this, "Session ${sessions.size} created", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this, "Maximum $maxSessions sessions reached", Toast.LENGTH_SHORT).show()
                        }
                    }
                    3 -> {
                        // Kill session - terminates shell, press Enter to close
                        killCurrentSession()
                    }
                    4 -> {
                        // Reset terminal - clear screen and reset state
                        session?.let { s ->
                            s.reset()
                            terminalView.onScreenUpdated()
                            Toast.makeText(this, "Terminal reset", Toast.LENGTH_SHORT).show()
                        }
                    }
                    5 -> {
                        // Change text size
                        showTextSizeDialog()
                    }
                    6 -> {
                        // Toggle keyboard
                        val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                        imm.toggleSoftInput(0, 0)
                    }
                    7 -> {
                        // About
                        showAboutDialog()
                    }
                }
            }
            .show()
    }

    private fun showTextSizeDialog() {
        val sizes = arrayOf("Small (14)", "Medium (20)", "Large (28)", "X-Large (36)", "XX-Large (48)")
        val sizeValues = intArrayOf(14, 20, 28, 36, 48)
        AlertDialog.Builder(this)
            .setTitle("Text Size")
            .setItems(sizes) { _, which ->
                currentTextSize = sizeValues[which]
                terminalView.setTextSize(currentTextSize)
                // Same pattern as pinch zoom - simple and reliable
                terminalView.post {
                    updateTerminalSize()
                    terminalView.onScreenUpdated()
                }
            }
            .show()
    }

    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("MobileCLI", text))
    }

    private fun pasteFromClipboard() {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.primaryClip?.getItemAt(0)?.text?.let { text ->
            // Handle multi-line paste properly
            val textStr = text.toString()
            session?.write(textStr.toByteArray(Charsets.UTF_8), 0, textStr.toByteArray(Charsets.UTF_8).size)
        }
    }

    override fun shouldBackButtonBeMappedToEscape(): Boolean = false
    override fun shouldEnforceCharBasedInput(): Boolean = true
    override fun shouldUseCtrlSpaceWorkaround(): Boolean = false
    override fun isTerminalViewSelected(): Boolean = true
    override fun copyModeChanged(copyMode: Boolean) {}

    override fun onKeyDown(keyCode: Int, e: KeyEvent?, session: TerminalSession?): Boolean = false
    override fun onKeyUp(keyCode: Int, e: KeyEvent?): Boolean = false

    override fun readControlKey(): Boolean = isCtrlPressed
    override fun readAltKey(): Boolean = isAltPressed
    override fun readShiftKey(): Boolean = false
    override fun readFnKey(): Boolean = false

    override fun onCodePoint(codePoint: Int, ctrlDown: Boolean, session: TerminalSession?): Boolean {
        // Immediately reset modifiers after a key is pressed (fixes Ctrl+C activating Alt bug)
        // Must be synchronous, not via post{}, to prevent race conditions
        val wasCtrl = isCtrlPressed
        val wasAlt = isAltPressed
        isCtrlPressed = false
        isAltPressed = false
        if (wasCtrl || wasAlt) {
            updateModifierButtons()
        }
        return false
    }

    override fun onEmulatorSet() {
        terminalView.setTerminalCursorBlinkerRate(500)
        updateTerminalSize()
    }

    override fun logError(tag: String?, message: String?) {
        android.util.Log.e(tag ?: "Terminal", message ?: "")
    }
    override fun logWarn(tag: String?, message: String?) {
        android.util.Log.w(tag ?: "Terminal", message ?: "")
    }
    override fun logInfo(tag: String?, message: String?) {
        android.util.Log.i(tag ?: "Terminal", message ?: "")
    }
    override fun logDebug(tag: String?, message: String?) {
        android.util.Log.d(tag ?: "Terminal", message ?: "")
    }
    override fun logVerbose(tag: String?, message: String?) {
        android.util.Log.v(tag ?: "Terminal", message ?: "")
    }
    override fun logStackTraceWithMessage(tag: String?, message: String?, e: Exception?) {
        android.util.Log.e(tag ?: "Terminal", message, e)
    }
    override fun logStackTrace(tag: String?, e: Exception?) {
        android.util.Log.e(tag ?: "Terminal", "Error", e)
    }

    // TerminalSessionClient implementation
    override fun onTextChanged(changedSession: TerminalSession?) {
        terminalView.onScreenUpdated()
    }

    override fun onTitleChanged(changedSession: TerminalSession?) {}

    override fun onSessionFinished(finishedSession: TerminalSession?) {
        // Find and remove the finished session
        val index = sessions.indexOf(finishedSession)
        if (index >= 0) {
            removeSession(index)
            Toast.makeText(this, "Session closed", Toast.LENGTH_SHORT).show()
        } else if (sessions.isEmpty()) {
            // No sessions left, create a new one
            addNewSession()
        }
    }

    override fun onCopyTextToClipboard(session: TerminalSession?, text: String?) {
        text?.let { copyToClipboard(it) }
    }

    override fun onPasteTextFromClipboard(session: TerminalSession?) {
        pasteFromClipboard()
    }

    override fun onBell(session: TerminalSession?) {
        try {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                vibrator.vibrate(android.os.VibrationEffect.createOneShot(50, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(50)
            }
        } catch (e: Exception) {}
    }

    override fun onColorsChanged(session: TerminalSession?) {
        terminalView.onScreenUpdated()
    }

    override fun onTerminalCursorStateChange(state: Boolean) {}

    override fun getTerminalCursorStyle(): Int = TerminalEmulator.TERMINAL_CURSOR_STYLE_BLOCK
}
